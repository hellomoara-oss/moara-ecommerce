import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  pt: {
    translation: {
      nav: {
        home: 'Home',
        collection: 'Coleção',
        ritual: 'O Ritual',
        quiz: 'Quiz',
        blog: 'Oráculo',
        contact: 'Contato'
      },
      banner: '10% off no primeiro ritual',
      hero: {
        title: 'Ervas antigas, cura moderna',
        subtitle: 'Bem-vinda ao seu portal de autocuidado',
        cta: 'Descobrir Coleção'
      },
      categories: {
        solar: 'Solares',
        lunar: 'Lunares',
        divine: 'Divinos',
        hair_oil: 'Óleos Capilares'
      },
      products: {
        featured: 'Produtos em Destaque',
        buyNow: 'Adicionar ao Carrinho',
        benefits: 'Benefícios',
        ingredients: 'Ingredientes',
        howToPrepare: 'Como Preparar'
      },
      newsletter: {
        title: 'Portal Místico',
        subtitle: 'Receba rituais e ofertas exclusivas',
        placeholder: 'Seu email',
        subscribe: 'Inscrever-se',
        success: 'Inscrito com sucesso!',
        error: 'Email já cadastrado'
      },
      quiz: {
        title: 'Encontre Seu Chá Ideal',
        subtitle: 'Responda e ganhe 10% de desconto',
        question: 'Qual seu principal desafio?',
        anxiety: 'Ansiedade e estresse',
        sleep: 'Dificuldade para dormir',
        pms: 'TPM e cólicas',
        submit: 'Ver Recomendação',
        result: 'Recomendamos para você',
        coupon: 'Use o cupom'
      },
      blog: {
        title: 'Oráculo',
        readMore: 'Ler mais',
        author: 'Por',
        relatedProducts: 'Produtos Relacionados'
      },
      footer: {
        about: 'Sobre Moara',
        aboutText: 'Ajudar a nascer. Auxiliar no parto. A essência.',
        shipping: 'Frete fixo para todo Brasil',
        payment: 'Pix, cartões e Correios'
      }
    }
  },
  en: {
    translation: {
      nav: {
        home: 'Home',
        collection: 'Collection',
        ritual: 'The Ritual',
        quiz: 'Quiz',
        blog: 'Oracle',
        contact: 'Contact'
      },
      banner: '10% off on your first ritual',
      hero: {
        title: 'Ancient herbs, modern healing',
        subtitle: 'Welcome to your self-care portal',
        cta: 'Discover Collection'
      },
      categories: {
        solar: 'Solar',
        lunar: 'Lunar',
        divine: 'Divine',
        hair_oil: 'Hair Oils'
      },
      products: {
        featured: 'Featured Products',
        buyNow: 'Add to Cart',
        benefits: 'Benefits',
        ingredients: 'Ingredients',
        howToPrepare: 'How to Prepare'
      },
      newsletter: {
        title: 'Mystical Portal',
        subtitle: 'Receive rituals and exclusive offers',
        placeholder: 'Your email',
        subscribe: 'Subscribe',
        success: 'Successfully subscribed!',
        error: 'Email already registered'
      },
      quiz: {
        title: 'Find Your Ideal Tea',
        subtitle: 'Answer and get 10% off',
        question: 'What is your main challenge?',
        anxiety: 'Anxiety and stress',
        sleep: 'Difficulty sleeping',
        pms: 'PMS and cramps',
        submit: 'See Recommendation',
        result: 'We recommend for you',
        coupon: 'Use coupon'
      },
      blog: {
        title: 'Oracle',
        readMore: 'Read more',
        author: 'By',
        relatedProducts: 'Related Products'
      },
      footer: {
        about: 'About Moara',
        aboutText: 'To help be born. To assist in birth. The essence.',
        shipping: 'Fixed shipping throughout Brazil',
        payment: 'Pix, cards and Postal Service'
      }
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'pt',
    fallbackLng: 'pt',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
