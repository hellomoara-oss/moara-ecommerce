import React, { createContext, useContext, useState, useEffect } from 'react';

const ReviewContext = createContext();

export const ReviewProvider = ({ children }) => {
  const [reviews, setReviews] = useState([]);

  // Carregar reviews do localStorage
  useEffect(() => {
    const savedReviews = localStorage.getItem('moara_reviews');
    if (savedReviews) {
      setReviews(JSON.parse(savedReviews));
    } else {
      // Reviews mockados iniciais
      setReviews([
        {
          id: 1,
          productId: 'cha-por-do-sol',
          author: 'Maria Silva',
          rating: 5,
          title: 'Transformou minha noite',
          comment: 'Comecei a beber este chá uma hora antes de dormir e meu sono melhorou muito. Recomendo!',
          date: '2024-01-20'
        },
        {
          id: 2,
          productId: 'cha-por-do-sol',
          author: 'Ana Costa',
          rating: 4,
          title: 'Muito bom, mas caro',
          comment: 'O chá é excelente, mas o preço é um pouco alto. Vale a pena para ocasiões especiais.',
          date: '2024-01-18'
        },
        {
          id: 3,
          productId: 'cha-lua-de-mel',
          author: 'Juliana Santos',
          rating: 5,
          title: 'Meu ritual diário',
          comment: 'Virou parte da minha rotina matinal. Adorei o aroma e os benefícios são reais.',
          date: '2024-01-15'
        },
        {
          id: 4,
          productId: 'cha-deusa',
          author: 'Carla Oliveira',
          rating: 5,
          title: 'Senti a diferença',
          comment: 'Tomei durante meu ciclo menstrual e realmente aliviou os desconfortos. Muito bom!',
          date: '2024-01-12'
        },
        {
          id: 5,
          productId: 'oleo-selvagem',
          author: 'Beatriz Lima',
          rating: 4,
          title: 'Cabelo mais forte',
          comment: 'Estou usando há 3 semanas e já vejo diferença. Cabelo mais brilhante e forte.',
          date: '2024-01-10'
        }
      ]);
    }
  }, []);

  // Salvar reviews no localStorage sempre que mudam
  useEffect(() => {
    localStorage.setItem('moara_reviews', JSON.stringify(reviews));
  }, [reviews]);

  const addReview = (productId, author, rating, title, comment) => {
    const newReview = {
      id: Math.max(...reviews.map(r => r.id), 0) + 1,
      productId,
      author,
      rating,
      title,
      comment,
      date: new Date().toISOString().split('T')[0]
    };
    setReviews([...reviews, newReview]);
    return newReview;
  };

  const getProductReviews = (productId) => {
    return reviews.filter(review => review.productId === productId);
  };

  const getAverageRating = (productId) => {
    const productReviews = getProductReviews(productId);
    if (productReviews.length === 0) return 0;
    const sum = productReviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / productReviews.length).toFixed(1);
  };

  const getRatingDistribution = (productId) => {
    const productReviews = getProductReviews(productId);
    const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    
    productReviews.forEach(review => {
      distribution[review.rating]++;
    });

    return distribution;
  };

  return (
    <ReviewContext.Provider
      value={{
        reviews,
        addReview,
        getProductReviews,
        getAverageRating,
        getRatingDistribution
      }}
    >
      {children}
    </ReviewContext.Provider>
  );
};

export const useReview = () => {
  const context = useContext(ReviewContext);
  if (!context) {
    throw new Error('useReview deve ser usado dentro de ReviewProvider');
  }
  return context;
};
