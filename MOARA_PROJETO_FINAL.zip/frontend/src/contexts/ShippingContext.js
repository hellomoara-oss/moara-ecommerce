import React, { createContext, useContext, useState } from 'react';

const ShippingContext = createContext();

export const ShippingProvider = ({ children }) => {
  const [shippingMethod, setShippingMethod] = useState('standard');
  const [zipCode, setZipCode] = useState('');
  const [shippingCost, setShippingCost] = useState(10);
  const [shippingTime, setShippingTime] = useState('5-7');

  // Simulador de frete baseado em CEP
  const calculateShipping = (cep, subtotal) => {
    if (!cep || cep.length < 5) {
      return { cost: 10, time: '5-7', method: 'standard' };
    }

    // Extrair região do CEP (primeiros 2 dígitos)
    const region = parseInt(cep.substring(0, 2));

    let cost = 10;
    let time = '5-7';

    // Simulação de regiões brasileiras
    if (region >= 1 && region <= 19) {
      // São Paulo
      cost = subtotal > 100 ? 0 : 12;
      time = '2-3';
    } else if (region >= 20 && region <= 28) {
      // Rio de Janeiro
      cost = subtotal > 100 ? 0 : 14;
      time = '3-4';
    } else if (region >= 29 && region <= 39) {
      // Minas Gerais
      cost = subtotal > 100 ? 0 : 16;
      time = '4-5';
    } else if (region >= 40 && region <= 48) {
      // Bahia
      cost = subtotal > 100 ? 0 : 18;
      time = '5-7';
    } else if (region >= 50 && region <= 56) {
      // Pernambuco
      cost = subtotal > 100 ? 0 : 20;
      time = '6-8';
    } else if (region >= 57 && region <= 63) {
      // Ceará
      cost = subtotal > 100 ? 0 : 22;
      time = '7-9';
    } else if (region >= 64 && region <= 72) {
      // Brasília/Centro-Oeste
      cost = subtotal > 100 ? 0 : 18;
      time = '5-7';
    } else if (region >= 73 && region <= 76) {
      // Goiás
      cost = subtotal > 100 ? 0 : 18;
      time = '5-7';
    } else if (region >= 77 && region <= 79) {
      // Mato Grosso do Sul
      cost = subtotal > 100 ? 0 : 20;
      time = '6-8';
    } else if (region >= 80 && region <= 87) {
      // Mato Grosso
      cost = subtotal > 100 ? 0 : 22;
      time = '7-9';
    } else if (region >= 88 && region <= 89) {
      // Santa Catarina
      cost = subtotal > 100 ? 0 : 16;
      time = '4-5';
    } else if (region >= 90 && region <= 99) {
      // Rio Grande do Sul
      cost = subtotal > 100 ? 0 : 16;
      time = '4-5';
    }

    return { cost, time, method: 'standard' };
  };

  const updateShipping = (cep, subtotal) => {
    const shipping = calculateShipping(cep, subtotal);
    setZipCode(cep);
    setShippingCost(shipping.cost);
    setShippingTime(shipping.time);
    setShippingMethod(shipping.method);
    return shipping;
  };

  const getExpressShipping = (subtotal) => {
    // Frete expresso (24-48h)
    const baseShipping = calculateShipping(zipCode, subtotal);
    return {
      cost: baseShipping.cost + 15,
      time: '1-2',
      method: 'express'
    };
  };

  const getScheduledShipping = (subtotal) => {
    // Frete agendado (mais barato)
    const baseShipping = calculateShipping(zipCode, subtotal);
    return {
      cost: Math.max(baseShipping.cost - 3, 0),
      time: '7-10',
      method: 'scheduled'
    };
  };

  const isFreeShipping = (subtotal) => {
    return subtotal > 100 && shippingCost === 0;
  };

  return (
    <ShippingContext.Provider
      value={{
        shippingMethod,
        zipCode,
        shippingCost,
        shippingTime,
        updateShipping,
        getExpressShipping,
        getScheduledShipping,
        calculateShipping,
        isFreeShipping
      }}
    >
      {children}
    </ShippingContext.Provider>
  );
};

export const useShipping = () => {
  const context = useContext(ShippingContext);
  if (!context) {
    throw new Error('useShipping deve ser usado dentro de ShippingProvider');
  }
  return context;
};
