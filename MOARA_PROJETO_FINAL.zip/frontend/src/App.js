import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import Header from './components/Header';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import Home from './pages/Home';
import Collection from './pages/Collection';
import ProductDetail from './pages/ProductDetail';
import Quiz from './pages/Quiz';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import Ritual from './pages/Ritual';
import Contact from './pages/Contact';
import Admin from './pages/Admin';
import Profile from './pages/Profile';
import Subscriptions from './pages/Subscriptions';
import Kits from './pages/Kits';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Oracle from './pages/Oracle';
import Favorites from './pages/Favorites';
import About from './pages/About';
import { ReviewProvider } from './contexts/ReviewContext';
import { ShippingProvider } from './contexts/ShippingContext';
import './App.css';

function App() {
  useEffect(() => {
    document.body.classList.add('cursor-mystical');
  }, []);

  return (
    <AuthProvider>
      <ReviewProvider>
      <ShippingProvider>
      <CartProvider>
      <BrowserRouter>
        <div className="App min-h-screen flex flex-col">
          <Toaster position="top-center" richColors />
          <Header />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/collection" element={<Collection />} />
              <Route path="/product/:slug" element={<ProductDetail />} />
              <Route path="/quiz" element={<Quiz />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/blog/:slug" element={<BlogPost />} />
              <Route path="/ritual" element={<Ritual />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/subscriptions" element={<Subscriptions />} />
              <Route path="/kits" element={<Kits />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/oracle" element={<Oracle />} />
              <Route path="/favorites" element={<Favorites />} />
              <Route path="/about" element={<About />} />
            </Routes>
          </main>
          <Footer />
          <WhatsAppButton />
        </div>
      </BrowserRouter>
      </CartProvider>
      </ShippingProvider>
      </ReviewProvider>
    </AuthProvider>
  );
}

export default App;
