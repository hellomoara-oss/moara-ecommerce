import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Globe, Menu, X, User, LogIn, ShoppingCart, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import AuthModal from './AuthModal';

const Header = () => {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const { getItemCount } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const toggleLanguage = () => {
    const newLang = i18n.language === 'pt' ? 'en' : 'pt';
    i18n.changeLanguage(newLang);
  };

  const navLinks = [
    { to: '/', label: t('nav.home') },
    { to: '/collection', label: t('nav.collection') },
    { to: '/kits', label: 'Kits' },
    { to: '/oracle', label: 'Oráculo' },
    { to: '/ritual', label: t('nav.ritual') },
    { to: '/quiz', label: t('nav.quiz') },
    { to: '/blog', label: t('nav.blog') },
    { to: '/contact', label: t('nav.contact') }
  ];

  return (
    <>
      {/* Announcement Banner */}
      <div data-testid="announcement-banner" className="bg-[#D4A017] text-[#5E0807] text-center py-2 px-4 text-sm font-medium">
        {t('banner')}
      </div>

      {/* Main Header */}
      <header data-testid="main-header" className="sticky top-0 z-50 bg-[#FAF3E0]/95 backdrop-blur-md border-b border-[#D4A017]/30">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" data-testid="logo-link" className="flex items-center">
              <h1 className="text-3xl md:text-4xl font-bold text-[#5E0807] tracking-tight" style={{ fontFamily: 'Playfair Display, serif' }}>
                Moara
              </h1>
            </Link>

            {/* Desktop Navigation */}
            <nav data-testid="desktop-nav" className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  data-testid={`nav-link-${link.to}`}
                  className="text-[#5E0807] hover:text-[#D4A017] font-medium transition-colors duration-300"
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Language Toggle & Mobile Menu */}
            <div className="flex items-center gap-4">
              {/* User/Login Button */}
              {user ? (
                <Link
                  to="/profile"
                  data-testid="profile-link"
                  className="flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] transition-colors"
                >
                  <User size={20} />
                  <span className="hidden md:inline text-sm font-medium">{user.name}</span>
                </Link>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  data-testid="login-btn"
                  className="flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] transition-colors"
                >
                  <LogIn size={20} />
                  <span className="hidden md:inline text-sm font-medium">Entrar</span>
                </button>
              )}

              <Link
                to="/favorites"
                data-testid="favorites-link"
                className="text-[#5E0807] hover:text-[#D4A017] transition-colors"
              >
                <Heart size={20} />
              </Link>

              <Link
                to="/cart"
                data-testid="cart-link"
                className="relative flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] transition-colors"
              >
                <ShoppingCart size={20} />
                {getItemCount() > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#8A1C2B] text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                    {getItemCount()}
                  </span>
                )}
              </Link>

              <button
                data-testid="language-toggle"
                onClick={toggleLanguage}
                className="flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] transition-colors"
              >
                <Globe size={20} />
                <span className="text-sm font-medium uppercase">{i18n.language}</span>
              </button>

              {/* Mobile Menu Toggle */}
              <button
                data-testid="mobile-menu-toggle"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden text-[#5E0807]"
              >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.nav
              data-testid="mobile-nav"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden border-t border-[#D4A017]/30 bg-[#FAF3E0]"
            >
              <div className="px-6 py-4 space-y-3">
                {navLinks.map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    data-testid={`mobile-nav-link-${link.to}`}
                    onClick={() => setMobileMenuOpen(false)}
                    className="block text-[#5E0807] hover:text-[#D4A017] font-medium py-2 transition-colors"
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </header>
      
      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </>
  );
};

export default Header;
