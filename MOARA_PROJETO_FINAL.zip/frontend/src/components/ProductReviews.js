import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, Send } from 'lucide-react';
import { toast } from 'sonner';
import { useReview } from '../contexts/ReviewContext';

const ProductReviews = ({ productId, productName }) => {
  const { getProductReviews, addReview, getAverageRating, getRatingDistribution } = useReview();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    author: '',
    rating: 5,
    title: '',
    comment: ''
  });

  const reviews = getProductReviews(productId);
  const averageRating = getAverageRating(productId);
  const distribution = getRatingDistribution(productId);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'rating' ? parseInt(value) : value
    }));
  };

  const handleSubmitReview = (e) => {
    e.preventDefault();
    
    if (!formData.author || !formData.title || !formData.comment) {
      toast.error('Por favor, preencha todos os campos');
      return;
    }

    addReview(
      productId,
      formData.author,
      formData.rating,
      formData.title,
      formData.comment
    );

    toast.success('Avaliação enviada com sucesso!');
    setFormData({ author: '', rating: 5, title: '', comment: '' });
    setShowForm(false);
  };

  const renderStars = (rating) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map(star => (
          <Star
            key={star}
            size={16}
            className={star <= rating ? 'fill-[#D4A017] text-[#D4A017]' : 'text-[#D4A017]/30'}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="mt-12 border-t border-[#D4A017]/30 pt-12">
      <h2 className="text-3xl font-serif text-[#5E0807] mb-8">Avaliações de Clientes</h2>

      {/* Rating Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        {/* Average Rating */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8 text-center"
        >
          <div className="text-5xl font-serif text-[#D4A017] mb-2">{averageRating}</div>
          <div className="flex justify-center mb-3">{renderStars(Math.round(averageRating))}</div>
          <p className="text-[#8C5E5E]">{reviews.length} avaliações</p>
        </motion.div>

        {/* Rating Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8 md:col-span-2"
        >
          {[5, 4, 3, 2, 1].map(rating => (
            <div key={rating} className="flex items-center gap-3 mb-3">
              <div className="flex gap-1 w-16">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star
                    key={star}
                    size={12}
                    className={star <= rating ? 'fill-[#D4A017] text-[#D4A017]' : 'text-[#D4A017]/30'}
                  />
                ))}
              </div>
              <div className="flex-1 bg-[#FAF3E0] rounded-full h-2">
                <div
                  className="bg-[#D4A017] h-2 rounded-full transition-all"
                  style={{
                    width: reviews.length > 0 ? `${(distribution[rating] / reviews.length) * 100}%` : '0%'
                  }}
                />
              </div>
              <span className="text-[#8C5E5E] text-sm w-8 text-right">{distribution[rating]}</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Add Review Button */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        onClick={() => setShowForm(!showForm)}
        className="bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-serif hover:bg-[#C59010] transition-all mb-8"
      >
        {showForm ? 'Cancelar' : 'Deixar uma Avaliação'}
      </motion.button>

      {/* Review Form */}
      {showForm && (
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSubmitReview}
          className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8 mb-12"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-[#5E0807] font-serif mb-2">Seu Nome</label>
              <input
                type="text"
                name="author"
                value={formData.author}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-[#D4A017]/30 rounded-sm focus:border-[#D4A017] outline-none"
                placeholder="Digite seu nome"
              />
            </div>
            <div>
              <label className="block text-[#5E0807] font-serif mb-2">Classificação</label>
              <select
                name="rating"
                value={formData.rating}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-[#D4A017]/30 rounded-sm focus:border-[#D4A017] outline-none"
              >
                <option value={5}>⭐⭐⭐⭐⭐ Excelente</option>
                <option value={4}>⭐⭐⭐⭐ Muito Bom</option>
                <option value={3}>⭐⭐⭐ Bom</option>
                <option value={2}>⭐⭐ Razoável</option>
                <option value={1}>⭐ Ruim</option>
              </select>
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-[#5E0807] font-serif mb-2">Título da Avaliação</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-[#D4A017]/30 rounded-sm focus:border-[#D4A017] outline-none"
              placeholder="Ex: Transformou minha rotina"
            />
          </div>

          <div className="mb-6">
            <label className="block text-[#5E0807] font-serif mb-2">Sua Avaliação</label>
            <textarea
              name="comment"
              value={formData.comment}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-[#D4A017]/30 rounded-sm focus:border-[#D4A017] outline-none resize-none"
              rows={4}
              placeholder="Compartilhe sua experiência com este produto..."
            />
          </div>

          <button
            type="submit"
            className="bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-serif hover:bg-[#C59010] transition-all flex items-center gap-2"
          >
            <Send size={18} />
            Enviar Avaliação
          </button>
        </motion.form>
      )}

      {/* Reviews List */}
      <div className="space-y-6">
        {reviews.length > 0 ? (
          reviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-6 hover:border-[#D4A017] transition-all"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-serif text-[#5E0807] text-lg">{review.title}</h4>
                  <p className="text-[#8C5E5E] text-sm">por {review.author}</p>
                </div>
                <span className="text-[#8C5E5E] text-sm">{review.date}</span>
              </div>

              <div className="mb-3">{renderStars(review.rating)}</div>

              <p className="text-[#8C5E5E] leading-relaxed">{review.comment}</p>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-8">
            <p className="text-[#8C5E5E]">Nenhuma avaliação ainda. Seja o primeiro a avaliar!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductReviews;
