import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Sun, Sparkles } from 'lucide-react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Footer = () => {
  const { t, i18n } = useTranslation();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post(`${BACKEND_URL}/api/newsletter`, {
        email,
        language: i18n.language
      });

      if (response.data.status === 'new') {
        toast.success(t('newsletter.success'));
        setEmail('');
      } else {
        toast.info(t('newsletter.error'));
      }
    } catch (error) {
      toast.error('Erro ao inscrever. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <footer data-testid="main-footer" className="bg-[#F5E6D3] border-t border-[#D4A017]/30 mt-20">
      {/* Newsletter Section */}
      <div data-testid="newsletter-section" className="bg-[#E8B9B9] py-12">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h3 className="text-3xl md:text-4xl font-medium text-[#5E0807] mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
            {t('newsletter.title')}
          </h3>
          <p className="text-[#5E0807]/80 mb-6">{t('newsletter.subtitle')}</p>
          
          <form data-testid="newsletter-form" onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              data-testid="newsletter-email-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t('newsletter.placeholder')}
              required
              className="flex-1 px-4 py-3 bg-white/80 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none text-[#5E0807] placeholder-[#5E0807]/40 rounded"
            />
            <button
              data-testid="newsletter-subscribe-btn"
              type="submit"
              disabled={loading}
              className="bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded font-medium hover:bg-[#C59010] transition-all duration-300 disabled:opacity-50"
            >
              {loading ? 'Enviando...' : t('newsletter.subscribe')}
            </button>
          </form>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About */}
          <div>
            <h4 className="text-2xl font-medium text-[#5E0807] mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
              Moara
            </h4>
            <p className="text-[#5E0807]/70 mb-4">{t('footer.aboutText')}</p>
          </div>

          {/* Quick Links */}
          <div>
            <h5 className="text-lg font-medium text-[#5E0807] mb-3">Links</h5>
            <ul className="space-y-2">
              <li><Link to="/collection" data-testid="footer-link-collection" className="text-[#5E0807]/70 hover:text-[#D4A017] transition-colors">{t('nav.collection')}</Link></li>
              <li><Link to="/about" className="text-[#5E0807]/70 hover:text-[#D4A017] transition-colors">Sobre</Link></li>
              <li><Link to="/quiz" data-testid="footer-link-quiz" className="text-[#5E0807]/70 hover:text-[#D4A017] transition-colors">{t('nav.quiz')}</Link></li>
              <li><Link to="/blog" data-testid="footer-link-blog" className="text-[#5E0807]/70 hover:text-[#D4A017] transition-colors">{t('nav.blog')}</Link></li>
              <li><Link to="/contact" data-testid="footer-link-contact" className="text-[#5E0807]/70 hover:text-[#D4A017] transition-colors">{t('nav.contact')}</Link></li>
            </ul>
          </div>

          {/* Info */}
          <div>
            <h5 className="text-lg font-medium text-[#5E0807] mb-3">Info</h5>
            <p className="text-[#5E0807]/70 mb-2">{t('footer.shipping')}</p>
            <p className="text-[#5E0807]/70 mb-4">{t('footer.payment')}</p>
            
            {/* Icons */}
            <div className="flex gap-4 mt-4">
              <div data-testid="icon-sun" className="w-8 h-8 rounded-full bg-[#D4A017] flex items-center justify-center">
                <Sun size={16} className="text-[#5E0807]" />
              </div>
              {/* Ícone da lua removido conforme solicitado */}
              <div data-testid="icon-sparkles" className="w-8 h-8 rounded-full bg-[#E8B9B9] flex items-center justify-center">
                <Sparkles size={16} className="text-[#5E0807]" />
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-[#D4A017]/30 pt-6 text-center">
          <p className="text-[#5E0807]/60 text-sm">
            © {new Date().getFullYear()} Moara Portal Linear. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
