import React, { useState } from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';

const AuthModal = ({ isOpen, onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        await login(formData.email, formData.password);
        toast.success('Login realizado com sucesso!');
      } else {
        await register(formData.name, formData.email, formData.password);
        toast.success('Conta criada com sucesso!');
      }
      onClose();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao processar requisição');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50"
            onClick={onClose}
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            data-testid="auth-modal"
            className="relative bg-[#FAF3E0] border-2 border-[#D4A017] rounded-sm p-8 max-w-md w-full mx-4 z-[101]"
          >
            <button
              onClick={onClose}
              data-testid="close-auth-modal"
              className="absolute top-4 right-4 text-[#5E0807] hover:text-[#D4A017]"
            >
              <X size={24} />
            </button>

            <h2 className="text-3xl font-medium text-[#5E0807] mb-6 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
              {isLogin ? 'Entrar' : 'Criar Conta'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Nome</label>
                  <input
                    type="text"
                    name="name"
                    data-testid="auth-name-input"
                    value={formData.name}
                    onChange={handleChange}
                    required={!isLogin}
                    className="w-full px-4 py-3 bg-white border border-[#D4A017]/30 focus:border-[#D4A017] outline-none text-[#5E0807] rounded"
                  />
                </div>
              )}

              <div>
                <label className="block text-[#5E0807] font-medium mb-2">Email</label>
                <input
                  type="email"
                  name="email"
                  data-testid="auth-email-input"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-white border border-[#D4A017]/30 focus:border-[#D4A017] outline-none text-[#5E0807] rounded"
                />
              </div>

              <div>
                <label className="block text-[#5E0807] font-medium mb-2">Senha</label>
                <input
                  type="password"
                  name="password"
                  data-testid="auth-password-input"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  minLength={6}
                  className="w-full px-4 py-3 bg-white border border-[#D4A017]/30 focus:border-[#D4A017] outline-none text-[#5E0807] rounded"
                />
              </div>

              <button
                type="submit"
                data-testid="auth-submit-btn"
                disabled={loading}
                className="w-full bg-[#D4A017] text-[#5E0807] py-3 rounded-full font-medium hover:bg-[#C59010] transition-all duration-300 disabled:opacity-50"
              >
                {loading ? 'Processando...' : (isLogin ? 'Entrar' : 'Criar Conta')}
              </button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => setIsLogin(!isLogin)}
                data-testid="toggle-auth-mode"
                className="text-[#D4A017] hover:text-[#C59010] font-medium"
              >
                {isLogin ? 'Não tem conta? Criar uma' : 'Já tem conta? Entrar'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default AuthModal;
