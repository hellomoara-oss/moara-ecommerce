import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { ExternalLink, ShoppingCart, Heart } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';

const ProductCard = ({ product }) => {
  const { i18n } = useTranslation();
  const { addToCart } = useCart();
  const lang = i18n.language;
  const [isFavorite, setIsFavorite] = React.useState(false);

  React.useEffect(() => {
    const favorites = JSON.parse(localStorage.getItem('moara_favorites') || '[]');
    setIsFavorite(favorites.includes(product.id));
  }, [product.id]);

  const handleAddToCart = () => {
    addToCart(product, 1);
    toast.success(`${product.name_pt} adicionado ao carrinho!`);
  };

  const handleToggleFavorite = () => {
    const favorites = JSON.parse(localStorage.getItem('moara_favorites') || '[]');
    const newFavorites = favorites.includes(product.id)
      ? favorites.filter(id => id !== product.id)
      : [...favorites, product.id];
    localStorage.setItem('moara_favorites', JSON.stringify(newFavorites));
    setIsFavorite(!isFavorite);
    toast.success(isFavorite ? 'Removido dos favoritos' : 'Adicionado aos favoritos');
  };

  const name = lang === 'pt' ? product.name_pt : product.name_en;
  const description = lang === 'pt' ? product.description_pt : product.description_en;

  return (
    <motion.div
      data-testid={`product-card-${product.slug}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="group relative bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 hover:border-[#D4A017] transition-all duration-500 overflow-hidden rounded-sm"
    >
      {/* Product Image */}
      <Link to={`/product/${product.slug}`}>
        <div className="aspect-square overflow-hidden relative">
          <img
            src={product.image_url}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        </div>
      </Link>
      <button
        onClick={handleToggleFavorite}
        className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full hover:bg-white transition-all"
      >
        <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#8A1C2B] text-[#8A1C2B]' : 'text-[#8C5E5E]'}`} />
      </button>

      {/* Product Info */}
      <div className="p-6">
        <Link to={`/product/${product.slug}`}>
          <h3 data-testid={`product-name-${product.slug}`} className="text-2xl font-medium text-[#5E0807] mb-2 group-hover:text-[#D4A017] transition-colors" style={{ fontFamily: 'Playfair Display, serif' }}>
            {name}
          </h3>
        </Link>
        
        <p className="text-[#5E0807]/70 text-sm mb-4 line-clamp-2">{description}</p>
        
        <div className="flex items-center justify-between">
          <span data-testid={`product-price-${product.slug}`} className="text-2xl font-medium text-[#D4A017]">
            R$ {product.price.toFixed(2)}
          </span>
          
          <div className="flex gap-2">
            <button
              onClick={handleAddToCart}
              className="bg-[#D4A017] text-[#5E0807] p-2 rounded-full hover:bg-[#C59010] transition-all transform hover:scale-110"
              title="Adicionar ao carrinho"
            >
              <ShoppingCart size={16} />
            </button>
            <Link
              to={`/product/${product.slug}`}
              data-testid={`view-details-btn-${product.slug}`}
              className="text-[#5E0807] hover:text-[#D4A017] font-medium text-sm flex items-center gap-1 transition-colors"
            >
              Ver detalhes
              <ExternalLink size={14} />
            </Link>
          </div>
        </div>
      </div>

      {/* Floral Corner */}
      <div className="absolute top-0 right-0 w-12 h-12 border-r border-t border-[#D4A017]/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <div className="absolute bottom-0 left-0 w-12 h-12 border-l border-b border-[#D4A017]/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
    </motion.div>
  );
};

export default ProductCard;
