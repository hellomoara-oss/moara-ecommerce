import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Truck, Clock, DollarSign, Check } from 'lucide-react';
import { toast } from 'sonner';
import { useShipping } from '../contexts/ShippingContext';

const ShippingCalculator = ({ subtotal = 0 }) => {
  const { updateShipping, getExpressShipping, getScheduledShipping, isFreeShipping } = useShipping();
  const [zipCode, setZipCode] = useState('');
  const [shippingOptions, setShippingOptions] = useState(null);
  const [selectedOption, setSelectedOption] = useState('standard');

  const handleCalculateShipping = () => {
    if (!zipCode || zipCode.length < 5) {
      toast.error('Por favor, digite um CEP válido');
      return;
    }

    const standard = updateShipping(zipCode, subtotal);
    const express = getExpressShipping(subtotal);
    const scheduled = getScheduledShipping(subtotal);

    setShippingOptions({
      standard,
      express,
      scheduled
    });

    setSelectedOption('standard');
    toast.success('Frete calculado com sucesso!');
  };

  const handleZipCodeChange = (e) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 8) value = value.slice(0, 8);
    if (value.length > 5) {
      value = value.slice(0, 5) + '-' + value.slice(5);
    }
    setZipCode(value);
  };

  const getShippingOption = (type) => {
    return shippingOptions?.[type];
  };

  const renderOption = (type, label, icon) => {
    const option = getShippingOption(type);
    if (!option) return null;

    const isSelected = selectedOption === type;
    const isFree = option.cost === 0;

    return (
      <motion.button
        key={type}
        onClick={() => setSelectedOption(type)}
        whileHover={{ scale: 1.02 }}
        className={`p-6 rounded-sm border-2 transition-all text-left ${
          isSelected
            ? 'border-[#D4A017] bg-[#D4A017]/10'
            : 'border-[#D4A017]/30 bg-white/50 hover:border-[#D4A017]'
        }`}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            {icon}
            <div>
              <h4 className="font-serif text-[#5E0807] text-lg">{label}</h4>
              <p className="text-[#8C5E5E] text-sm">
                {option.time} dias úteis
              </p>
            </div>
          </div>
          {isSelected && (
            <Check className="w-6 h-6 text-[#D4A017]" />
          )}
        </div>

        <div className="flex items-baseline gap-2">
          {isFree ? (
            <span className="text-2xl font-serif text-[#4A7C59]">Grátis</span>
          ) : (
            <>
              <span className="text-2xl font-serif text-[#D4A017]">
                R$ {option.cost.toFixed(2)}
              </span>
              <span className="text-[#8C5E5E] text-sm">
                {subtotal > 100 && option.cost === 0 ? '(Frete grátis!)' : ''}
              </span>
            </>
          )}
        </div>
      </motion.button>
    );
  };

  return (
    <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8">
      <h3 className="text-2xl font-serif text-[#5E0807] mb-6">Calcular Frete</h3>

      {/* CEP Input */}
      <div className="mb-6">
        <label className="block text-[#5E0807] font-serif mb-2">CEP de Entrega</label>
        <div className="flex gap-3">
          <input
            type="text"
            value={zipCode}
            onChange={handleZipCodeChange}
            placeholder="00000-000"
            className="flex-1 px-4 py-3 border border-[#D4A017]/30 rounded-sm focus:border-[#D4A017] outline-none"
          />
          <button
            onClick={handleCalculateShipping}
            className="bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-sm font-serif hover:bg-[#C59010] transition-all"
          >
            Calcular
          </button>
        </div>
      </div>

      {/* Free Shipping Info */}
      {subtotal > 100 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 bg-[#4A7C59]/10 border border-[#4A7C59]/30 rounded-sm p-4"
        >
          <p className="text-[#4A7C59] font-serif">
            ✨ Você tem direito a frete grátis! Compras acima de R$ 100 têm frete gratuito.
          </p>
        </motion.div>
      )}

      {/* Shipping Options */}
      {shippingOptions && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <h4 className="font-serif text-[#5E0807] mb-4">Escolha a opção de entrega:</h4>

          {renderOption(
            'standard',
            'Entrega Padrão',
            <Truck className="w-6 h-6 text-[#D4A017]" />
          )}

          {renderOption(
            'express',
            'Entrega Expressa',
            <Clock className="w-6 h-6 text-[#D4A017]" />
          )}

          {renderOption(
            'scheduled',
            'Entrega Agendada',
            <DollarSign className="w-6 h-6 text-[#D4A017]" />
          )}

          {/* Summary */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 p-4 bg-gradient-to-r from-[#D4A017]/10 to-[#8A1C2B]/10 rounded-sm border border-[#D4A017]/30"
          >
            <div className="flex justify-between items-center mb-2">
              <span className="text-[#8C5E5E]">Subtotal:</span>
              <span className="font-serif text-[#5E0807]">R$ {subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center mb-3 pb-3 border-b border-[#D4A017]/30">
              <span className="text-[#8C5E5E]">Frete:</span>
              <span className="font-serif text-[#D4A017]">
                {getShippingOption(selectedOption)?.cost === 0
                  ? 'Grátis'
                  : `R$ ${getShippingOption(selectedOption)?.cost.toFixed(2)}`}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-serif text-[#5E0807] text-lg">Total:</span>
              <span className="font-serif text-[#D4A017] text-2xl">
                R$ {(subtotal + (getShippingOption(selectedOption)?.cost || 0)).toFixed(2)}
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Info Box */}
      {!shippingOptions && (
        <div className="p-4 bg-[#FAF3E0] border border-[#D4A017]/30 rounded-sm text-center">
          <p className="text-[#8C5E5E] text-sm">
            Digite seu CEP e clique em "Calcular" para ver as opções de entrega
          </p>
        </div>
      )}
    </div>
  );
};

export default ShippingCalculator;
