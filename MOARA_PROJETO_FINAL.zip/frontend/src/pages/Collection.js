import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import ProductCard from '../components/ProductCard';
import { Filter } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Collection = () => {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || 'all');

  useEffect(() => {
    fetchProducts();
  }, [selectedCategory]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const url = selectedCategory === 'all'
        ? `${BACKEND_URL}/api/products`
        : `${BACKEND_URL}/api/products?category=${selectedCategory}`;
      
      const response = await axios.get(url);
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    if (category === 'all') {
      setSearchParams({});
    } else {
      setSearchParams({ category });
    }
  };

  const categories = [
    { value: 'all', label: 'Todos', label_en: 'All' },
    { value: 'solar', label: t('categories.solar') },
    { value: 'lunar', label: t('categories.lunar') },
    { value: 'divine', label: t('categories.divine') },
    { value: 'hair_oil', label: t('categories.hair_oil') },
    { value: 'body_oil', label: 'Óleos Corporais', label_en: 'Body Oils' }
  ];

  return (
    <div data-testid="collection-page" className="min-h-screen py-12 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 data-testid="collection-title" className="text-5xl md:text-6xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            {t('nav.collection')}
          </h1>
          <p className="text-lg text-[#5E0807]/70">
            Descubra nossa coleção de chás místicos e naturais
          </p>
        </div>

        {/* Filters */}
        <div data-testid="filter-section" className="mb-8 flex flex-wrap items-center gap-3 justify-center">
          <div className="flex items-center gap-2 text-[#5E0807] font-medium">
            <Filter size={18} />
            <span>Filtrar:</span>
          </div>
          
          {categories.map((category) => (
            <button
              key={category.value}
              data-testid={`filter-btn-${category.value}`}
              onClick={() => handleCategoryChange(category.value)}
              className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                selectedCategory === category.value
                  ? 'bg-[#D4A017] text-[#5E0807] shadow-lg'
                  : 'bg-white/50 text-[#5E0807] border border-[#D4A017]/30 hover:border-[#D4A017]'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="text-center text-[#5E0807]/70 py-20">Carregando produtos...</div>
        ) : products.length === 0 ? (
          <div data-testid="no-products-message" className="text-center text-[#5E0807]/70 py-20">
            Nenhum produto encontrado nesta categoria.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Collection;
