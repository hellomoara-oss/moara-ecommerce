import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { ArrowLeft, Check } from 'lucide-react';
import ShippingCalculator from '../components/ShippingCalculator';

const Checkout = () => {
  const navigate = useNavigate();
  const { cartItems, getSubtotal, getShippingCost, getTotal, clearCart } = useCart();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    cpf: '',
    address: '',
    number: '',
    complement: '',
    city: '',
    state: '',
    zipCode: '',
    paymentMethod: 'pix',
  });

  const [orderCreated, setOrderCreated] = useState(null);

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-[#FAF3E0] pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24 text-center">
          <h1 className="text-4xl font-serif text-[#5E0807] mb-4">Carrinho Vazio</h1>
          <p className="text-lg text-[#8C5E5E] mb-8">Adicione produtos antes de fazer checkout</p>
          <button
            onClick={() => navigate('/collection')}
            className="bg-[#D4A017] text-[#5E0807] px-8 py-3 rounded-full font-serif hover:bg-[#C59010]"
          >
            Voltar para Coleção
          </button>
        </div>
      </div>
    );
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateStep1 = () => {
    if (!formData.fullName || !formData.email || !formData.phone || !formData.cpf) {
      toast.error('Por favor, preencha todos os campos obrigatórios');
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (!formData.address || !formData.number || !formData.city || !formData.state || !formData.zipCode) {
      toast.error('Por favor, preencha todos os campos de endereço');
      return false;
    }
    return true;
  };

  const handleCreateOrder = async () => {
    if (!validateStep2()) return;

    setLoading(true);
    try {
      const orderData = {
        items: cartItems.map(item => ({
          product_id: item.id,
          quantity: item.quantity,
          price: item.price,
        })),
        total: getTotal(),
        customer_email: formData.email,
        customer_name: formData.fullName,
        customer_phone: formData.phone,
        customer_cpf: formData.cpf,
        shipping_address: {
          address: formData.address,
          number: formData.number,
          complement: formData.complement,
          city: formData.city,
          state: formData.state,
          zip_code: formData.zipCode,
        },
        payment_method: formData.paymentMethod,
      };

      // Simular criação de pedido
      const response = await fetch('http://localhost:8001/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData),
      });

      if (response.ok) {
        const order = await response.json();
        setOrderCreated(order);
        setStep(3);
        toast.success('Pedido criado com sucesso!');
      } else {
        toast.error('Erro ao criar pedido');
      }
    } catch (error) {
      console.error('Erro:', error);
      toast.error('Erro ao processar pedido');
    } finally {
      setLoading(false);
    }
  };

  const handleFinish = () => {
    clearCart();
    navigate('/');
    toast.success('Obrigado pela compra!');
  };

  return (
    <div className="min-h-screen bg-[#FAF3E0] pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mb-12"
        >
          <button
            onClick={() => navigate('/cart')}
            className="flex items-center gap-2 text-[#D4A017] hover:text-[#C59010] mb-6 font-serif"
          >
            <ArrowLeft className="w-5 h-5" />
            Voltar para Carrinho
          </button>
          <h1 className="text-5xl font-serif text-[#5E0807] mb-2">Checkout</h1>
          <p className="text-lg text-[#8C5E5E]">Etapa {step} de 3</p>
        </motion.div>

        {/* Progress Bar */}
        <div className="mb-12 flex gap-4">
          {[1, 2, 3].map(s => (
            <div key={s} className="flex-1">
              <div className={`h-2 rounded-full transition-all ${s <= step ? 'bg-[#D4A017]' : 'bg-[#D4A017]/20'}`} />
              <p className="text-sm text-[#8C5E5E] mt-2">
                {s === 1 ? 'Dados Pessoais' : s === 2 ? 'Endereço' : 'Confirmação'}
              </p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Formulário */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8"
            >
              {step === 1 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-serif text-[#5E0807] mb-8">Dados Pessoais</h2>
                  
                  <div>
                    <label className="block text-[#5E0807] font-serif mb-2">Nome Completo *</label>
                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                      placeholder="Seu nome completo"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[#5E0807] font-serif mb-2">Email *</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                        placeholder="seu@email.com"
                      />
                    </div>
                    <div>
                      <label className="block text-[#5E0807] font-serif mb-2">Telefone *</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[#5E0807] font-serif mb-2">CPF *</label>
                    <input
                      type="text"
                      name="cpf"
                      value={formData.cpf}
                      onChange={handleInputChange}
                      className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                      placeholder="000.000.000-00"
                    />
                  </div>

                  <button
                    onClick={() => validateStep1() && setStep(2)}
                    className="w-full bg-[#D4A017] text-[#5E0807] py-3 rounded-full font-serif hover:bg-[#C59010] transition-all mt-8"
                  >
                    Próximo: Endereço
                  </button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-serif text-[#5E0807] mb-8">Endereço de Entrega</h2>
                  
                  <div>
                    <label className="block text-[#5E0807] font-serif mb-2">Endereço *</label>
                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                      placeholder="Rua, Avenida, etc"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[#5E0807] font-serif mb-2">Número *</label>
                      <input
                        type="text"
                        name="number"
                        value={formData.number}
                        onChange={handleInputChange}
                        className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                        placeholder="123"
                      />
                    </div>
                    <div>
                      <label className="block text-[#5E0807] font-serif mb-2">Complemento</label>
                      <input
                        type="text"
                        name="complement"
                        value={formData.complement}
                        onChange={handleInputChange}
                        className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                        placeholder="Apto, sala, etc"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[#5E0807] font-serif mb-2">Cidade *</label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                        placeholder="São Paulo"
                      />
                    </div>
                    <div>
                      <label className="block text-[#5E0807] font-serif mb-2">Estado *</label>
                      <input
                        type="text"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                        placeholder="SP"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[#5E0807] font-serif mb-2">CEP *</label>
                    <input
                      type="text"
                      name="zipCode"
                      value={formData.zipCode}
                      onChange={handleInputChange}
                      className="w-full bg-transparent border-b border-[#5E0807]/20 focus:border-[#D4A017] outline-none px-0 py-2 font-serif"
                      placeholder="00000-000"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4 mt-8">
                    <button
                      onClick={() => setStep(1)}
                      className="border border-[#D4A017] text-[#5E0807] py-3 rounded-full font-serif hover:bg-[#FAF3E0] transition-all"
                    >
                      Voltar
                    </button>
                    <button
                      onClick={() => validateStep2() && setStep(3)}
                      className="bg-[#D4A017] text-[#5E0807] py-3 rounded-full font-serif hover:bg-[#C59010] transition-all"
                    >
                      Próximo: Pagamento
                    </button>
                  </div>
                </div>
              )}

              {step === 3 && !orderCreated && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-serif text-[#5E0807] mb-8">Método de Pagamento</h2>
                  
                  <div className="space-y-4">
                    {['pix', 'credit_card', 'boleto'].map(method => (
                      <label key={method} className="flex items-center gap-4 p-4 border border-[#D4A017]/30 rounded-sm cursor-pointer hover:bg-[#FAF3E0] transition-all">
                        <input
                          type="radio"
                          name="paymentMethod"
                          value={method}
                          checked={formData.paymentMethod === method}
                          onChange={handleInputChange}
                          className="w-5 h-5"
                        />
                        <span className="font-serif text-[#5E0807]">
                          {method === 'pix' ? 'PIX (Instantâneo)' : method === 'credit_card' ? 'Cartão de Crédito' : 'Boleto Bancário'}
                        </span>
                      </label>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-4 mt-8">
                    <button
                      onClick={() => setStep(2)}
                      className="border border-[#D4A017] text-[#5E0807] py-3 rounded-full font-serif hover:bg-[#FAF3E0] transition-all"
                    >
                      Voltar
                    </button>
                  <ShippingCalculator subtotal={getSubtotal()} />

                  <button
                    onClick={() => handleCreateOrder()}
                    disabled={loading}
                    className="w-full bg-[#D4A017] text-[#5E0807] py-3 rounded-full font-serif hover:bg-[#C59010] transition-all mt-8 disabled:opacity-50"
                  >
                    {loading ? 'Processando...' : 'Próximo: Pagamento'}
                  </button>
                  </div>
                </div>
              )}

              {step === 3 && orderCreated && (
                <div className="text-center py-12">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-20 h-20 bg-[#4A7C59] rounded-full flex items-center justify-center mx-auto mb-6"
                  >
                    <Check className="w-12 h-12 text-white" />
                  </motion.div>
                  <h2 className="text-3xl font-serif text-[#5E0807] mb-4">Pedido Confirmado!</h2>
                  <p className="text-lg text-[#8C5E5E] mb-2">Número do pedido: <strong>{orderCreated.id}</strong></p>
                  <p className="text-[#8C5E5E] mb-8">Um email de confirmação foi enviado para {formData.email}</p>
                  <button
                    onClick={handleFinish}
                    className="bg-[#D4A017] text-[#5E0807] px-8 py-3 rounded-full font-serif hover:bg-[#C59010] transition-all"
                  >
                    Voltar para Home
                  </button>
                </div>
              )}
            </motion.div>
          </div>

          {/* Resumo do Pedido */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-1"
          >
            <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8 sticky top-32 space-y-6">
              <h2 className="text-2xl font-serif text-[#5E0807]">Seu Pedido</h2>

              <div className="space-y-4 max-h-96 overflow-y-auto">
                {cartItems.map(item => (
                  <div key={item.id} className="flex justify-between text-sm text-[#8C5E5E] pb-4 border-b border-[#D4A017]/20">
                    <span>{item.name_pt} x{item.quantity}</span>
                    <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-4 pb-6 border-b border-[#D4A017]/20">
                <div className="flex justify-between text-[#8C5E5E]">
                  <span>Subtotal:</span>
                  <span>R$ {getSubtotal().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#8C5E5E]">
                  <span>Frete:</span>
                  <span>R$ {getShippingCost().toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between text-xl font-serif text-[#5E0807]">
                <span>Total:</span>
                <span>R$ {getTotal().toFixed(2)}</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
