import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Check, Sparkles, Sun, Heart, Wind } from 'lucide-react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Quiz = () => {
  const { t } = useTranslation();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const questions = [
    {
      id: 'concern',
      question_pt: 'Qual é a sua maior necessidade neste momento?',
      question_en: 'What is your greatest need at this moment?',
      icon: <Heart className="text-[#D4A017]" size={48} />,
      options: [
        { id: 'stress', label_pt: 'Aliviar estresse e ansiedade', label_en: 'Relieve stress and anxiety', emoji: '🌅' },
        { id: 'sleep', label_pt: 'Melhorar qualidade do sono', label_en: 'Improve sleep quality', emoji: '🌙' },
        { id: 'energy', label_pt: 'Aumentar energia e clareza mental', label_en: 'Increase energy and mental clarity', emoji: '✨' },
        { id: 'cycle', label_pt: 'Cuidado menstrual e TPM', label_en: 'Menstrual care and PMS', emoji: '🌸' }
      ]
    },
    {
      id: 'phase',
      question_pt: 'Como você sente sua energia hoje?',
      question_en: 'How do you feel your energy today?',
      icon: <Wind className="text-[#D4A017]" size={48} />,
      options: [
        { id: 'rest', label_pt: 'Introspecção e descanso', label_en: 'Introspection and rest', emoji: '✨' },
        { id: 'growth', label_pt: 'Crescimento e expansão', label_en: 'Growth and expansion', emoji: '🌱' },
        { id: 'action', label_pt: 'Ação e realização', label_en: 'Action and achievement', emoji: '🔥' },
        { id: 'release', label_pt: 'Liberação e renovação', label_en: 'Release and renewal', emoji: '🍃' }
      ]
    },
    {
      id: 'ritual',
      question_pt: 'Que tipo de ritual você busca?',
      question_en: 'What type of ritual do you seek?',
      icon: <Sun className="text-[#D4A017]" size={48} />,
      options: [
        { id: 'morning', label_pt: 'Ritual matinal energizante', label_en: 'Energizing morning ritual', emoji: '☀️' },
        { id: 'night', label_pt: 'Ritual noturno relaxante', label_en: 'Relaxing night ritual', emoji: '🌜' },
        { id: 'body', label_pt: 'Cuidado corporal e pele', label_en: 'Body and skin care', emoji: '🧴' },
        { id: 'hair', label_pt: 'Fortalecimento capilar', label_en: 'Hair strengthening', emoji: '💆‍♀️' }
      ]
    }
  ];

  const handleAnswer = (optionId) => {
    const newAnswers = { ...answers, [questions[currentQuestion].id]: optionId };
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      submitQuiz(newAnswers);
    }
  };

  const submitQuiz = async (finalAnswers) => {
    setLoading(true);
    
    // Lógica de recomendação inteligente
    const { concern, phase, ritual } = finalAnswers;
    
    let recommendedProduct = 'por-do-sol';
    let couponCode = 'RITUAL10';
    
    // Recomendação baseada nas 3 respostas
    if (ritual === 'hair') {
      recommendedProduct = 'oleo-selvagem';
      couponCode = 'SELVAGEM10';
    } else if (concern === 'cycle') {
      recommendedProduct = 'cha-da-deusa';
      couponCode = 'DEUSA10';
    } else if (concern === 'energy' || phase === 'growth') {
      recommendedProduct = 'artemisia-pura';
      couponCode = 'MAGIA10';
    } else if (concern === 'sleep' || ritual === 'night' || concern === 'stress') {
      recommendedProduct = 'melissa-paz';
      couponCode = 'PAZ10';
    } else {
      recommendedProduct = 'por-do-sol';
      couponCode = 'SOLAR10';
    }

    try {
      await axios.post(`${BACKEND_URL}/api/quiz`, finalAnswers);
    } catch (error) {
      console.error('Error submitting quiz:', error);
    }

    setResult({ recommended_product: recommendedProduct, coupon_code: couponCode });
    setLoading(false);
  };

  const handleReset = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setResult(null);
  };

  const currentQ = questions[currentQuestion];

  return (
    <div data-testid="quiz-page" className="min-h-screen py-20 px-6 md:px-12 relative overflow-hidden">
      {/* Mystical Background - apenas orbes sutis */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="absolute w-96 h-96 rounded-full bg-[#D4A017]/5 blur-3xl"
          style={{ top: '10%', left: '10%' }}
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full bg-[#E8B9B9]/5 blur-3xl"
          style={{ bottom: '10%', right: '10%' }}
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.5, 0.3, 0.5] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <AnimatePresence mode="wait">
          {!result && currentQuestion === 0 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <Sparkles className="mx-auto text-[#D4A017] mb-6 animate-pulse" size={64} />
              <h1 data-testid="quiz-title" className="text-5xl md:text-6xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                {t('quiz.title')}
              </h1>
              <p className="text-xl text-[#5E0807]/70 mb-8">{t('quiz.subtitle')}</p>
              <p className="text-lg text-[#5E0807]/60 mb-8">
                Responda 3 perguntas e descubra o produto perfeito para você
              </p>
            </motion.div>
          )}

          {!result && currentQuestion >= 0 && (
            <motion.div
              key={`question-${currentQuestion}`}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="bg-white/60 backdrop-blur-md border-2 border-[#D4A017]/40 p-8 md:p-12 rounded-lg shadow-2xl"
            >
              {/* Progress Bar */}
              <div className="mb-8">
                <div className="flex justify-between text-sm text-[#5E0807]/60 mb-2">
                  <span>Pergunta {currentQuestion + 1} de {questions.length}</span>
                  <span>{Math.round(((currentQuestion + 1) / questions.length) * 100)}%</span>
                </div>
                <div className="h-2 bg-[#FAF3E0] rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#D4A017] to-[#E8B9B9]"
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>

              <div className="text-center mb-8">
                {currentQ.icon}
              </div>

              <h2 data-testid="quiz-question" className="text-3xl md:text-4xl font-medium text-[#5E0807] mb-8 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
                {currentQ.question_pt}
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentQ.options.map((option, index) => (
                  <motion.button
                    key={option.id}
                    data-testid={`quiz-option-${option.id}`}
                    onClick={() => handleAnswer(option.id)}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.03, boxShadow: '0 10px 40px rgba(212, 160, 23, 0.2)' }}
                    whileTap={{ scale: 0.98 }}
                    className="group p-6 rounded-lg border-2 border-[#D4A017]/30 hover:border-[#D4A017] bg-white/80 hover:bg-[#D4A017]/5 transition-all duration-300 text-left"
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-4xl">{option.emoji}</span>
                      <span className="text-lg text-[#5E0807] group-hover:text-[#D4A017] transition-colors font-medium">
                        {option.label_pt}
                      </span>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {result && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center"
            >
              <div className="bg-gradient-to-br from-[#E8B9B9]/80 to-[#D4A017]/30 backdrop-blur-md p-8 md:p-12 rounded-lg border-2 border-[#D4A017] mb-8 relative overflow-hidden">
                {/* Sparkle effects */}
                {[...Array(15)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-2 h-2 bg-[#D4A017] rounded-full"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                    }}
                    animate={{
                      scale: [0, 1.5, 0],
                      opacity: [0, 1, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: Math.random() * 2,
                    }}
                  />
                ))}

                <Sparkles className="mx-auto text-[#D4A017] mb-6 relative z-10" size={64} />
                <h2 className="text-3xl md:text-4xl font-medium text-[#5E0807] mb-6 relative z-10" style={{ fontFamily: 'Playfair Display, serif' }}>
                  {t('quiz.result')}
                </h2>
                
                <Link
                  to={`/product/${result.recommended_product}`}
                  data-testid="recommended-product-link"
                  className="inline-block text-4xl font-medium text-[#5E0807] hover:text-[#D4A017] transition-colors mb-6 relative z-10"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  {result.recommended_product === 'por-do-sol' && 'Pôr do Sol 🌅'}
                  {result.recommended_product === 'melissa-paz' && 'Melissa & Paz ✨'}
                  {result.recommended_product === 'cha-da-deusa' && 'Chá da Deusa 🌸'}
                  {result.recommended_product === 'artemisia-pura' && 'Artemísia Pura 🌿'}
                  {result.recommended_product === 'oleo-selvagem' && 'Óleo Selvagem 💆‍♀️'}
                </Link>

                <div className="bg-white/90 border-2 border-dashed border-[#D4A017] p-6 rounded-lg inline-block relative z-10">
                  <p className="text-sm text-[#5E0807]/70 mb-2">{t('quiz.coupon')}</p>
                  <p data-testid="coupon-code" className="text-3xl font-bold text-[#D4A017]">{result.coupon_code}</p>
                </div>
              </div>

              <div className="flex gap-4 justify-center flex-wrap">
                <Link
                  to={`/product/${result.recommended_product}`}
                  data-testid="view-product-btn"
                  className="inline-flex items-center gap-2 bg-[#D4A017] text-[#5E0807] px-8 py-4 rounded-full font-medium hover:bg-[#C59010] transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
                >
                  Ver Produto
                  <ArrowRight size={18} />
                </Link>
                
                <button
                  data-testid="restart-quiz-btn"
                  onClick={handleReset}
                  className="border-2 border-[#D4A017] text-[#5E0807] px-8 py-4 rounded-full font-medium hover:bg-[#D4A017]/10 transition-all duration-300"
                >
                  Fazer Novamente
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Quiz;
