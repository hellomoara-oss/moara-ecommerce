import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Mail, MessageCircle, Send } from 'lucide-react';
import { toast } from 'sonner';

const Contact = () => {
  const { t, i18n } = useTranslation();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [sending, setSending] = useState(false);
  const lang = i18n.language;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSending(true);

    // Simulate sending
    setTimeout(() => {
      toast.success(lang === 'pt' ? 'Mensagem enviada com sucesso!' : 'Message sent successfully!');
      setFormData({ name: '', email: '', message: '' });
      setSending(false);
    }, 1000);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div data-testid="contact-page" className="min-h-screen py-12 px-6 md:px-12">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 data-testid="contact-title" className="text-5xl md:text-6xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            {lang === 'pt' ? 'Contato' : 'Contact'}
          </h1>
          <p className="text-lg text-[#5E0807]/70">
            {lang === 'pt'
              ? 'Entre em contato conosco. Estamos aqui para ajudar você.'
              : 'Get in touch with us. We are here to help you.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Contact Info */}
          <div className="space-y-6">
            <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 p-6 rounded-sm">
              <div className="flex items-start gap-4">
                <Mail className="text-[#D4A017] mt-1" size={24} />
                <div>
                  <h3 className="text-xl font-medium text-[#5E0807] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                    Email
                  </h3>
                  <p className="text-[#5E0807]/70">contato@moara.com.br</p>
                </div>
              </div>
            </div>

            <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 p-6 rounded-sm">
              <div className="flex items-start gap-4">
                <MessageCircle className="text-[#D4A017] mt-1" size={24} />
                <div>
                  <h3 className="text-xl font-medium text-[#5E0807] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                    WhatsApp
                  </h3>
                  <p className="text-[#5E0807]/70">+55 (11) 98765-4321</p>
                </div>
              </div>
            </div>

            <div className="bg-[#F5E6D3] border border-[#D4A017]/30 p-6 rounded-sm">
              <h3 className="text-xl font-medium text-[#5E0807] mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
                {lang === 'pt' ? 'Horário de Atendimento' : 'Business Hours'}
              </h3>
              <p className="text-[#5E0807]/70">
                {lang === 'pt'
                  ? 'Segunda a Sexta: 9h às 18h'
                  : 'Monday to Friday: 9am to 6pm'}
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <form data-testid="contact-form" onSubmit={handleSubmit} className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 p-8 rounded-sm">
            <div className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-[#5E0807] font-medium mb-2">
                  {lang === 'pt' ? 'Nome' : 'Name'}
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  data-testid="contact-name-input"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-white border border-[#D4A017]/30 focus:border-[#D4A017] outline-none text-[#5E0807] rounded"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-[#5E0807] font-medium mb-2">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  data-testid="contact-email-input"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-white border border-[#D4A017]/30 focus:border-[#D4A017] outline-none text-[#5E0807] rounded"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-[#5E0807] font-medium mb-2">
                  {lang === 'pt' ? 'Mensagem' : 'Message'}
                </label>
                <textarea
                  id="message"
                  name="message"
                  data-testid="contact-message-input"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 bg-white border border-[#D4A017]/30 focus:border-[#D4A017] outline-none text-[#5E0807] rounded resize-none"
                />
              </div>

              <button
                type="submit"
                data-testid="contact-submit-btn"
                disabled={sending}
                className="w-full bg-[#D4A017] text-[#5E0807] py-3 rounded-full font-medium hover:bg-[#C59010] transition-all duration-300 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {sending ? (
                  lang === 'pt' ? 'Enviando...' : 'Sending...'
                ) : (
                  <>
                    <Send size={18} />
                    {lang === 'pt' ? 'Enviar Mensagem' : 'Send Message'}
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
