import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { ArrowRight, Calendar, User } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Blog = () => {
  const { t, i18n } = useTranslation();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const lang = i18n.language;

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/blog?published=true`);
      setPosts(response.data);
    } catch (error) {
      console.error('Error fetching blog posts:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div data-testid="blog-page" className="min-h-screen py-12 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 data-testid="blog-title" className="text-5xl md:text-6xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            {t('blog.title')}
          </h1>
          <p className="text-lg text-[#5E0807]/70">
            Sabedoria ancestral, rituais e guias de autocuidado
          </p>
        </div>

        {/* Admin Link */}
        <div className="text-center mb-8">
          <Link
            to="/admin"
            data-testid="admin-link"
            className="inline-block text-sm text-[#D4A017] hover:text-[#C59010] transition-colors"
          >
            Área Administrativa →
          </Link>
        </div>

        {/* Posts Grid */}
        {loading ? (
          <div className="text-center text-[#5E0807]/70 py-20">Carregando posts...</div>
        ) : posts.length === 0 ? (
          <div data-testid="no-posts-message" className="text-center text-[#5E0807]/70 py-20">
            Nenhum post publicado ainda. Em breve novos conteúdos!
          </div>
        ) : (
          <div className="space-y-8">
            {posts.map((post, index) => {
              const title = lang === 'pt' ? post.title_pt : post.title_en;
              const excerpt = lang === 'pt' ? post.excerpt_pt : post.excerpt_en;
              
              return (
                <motion.article
                  key={post.id}
                  data-testid={`blog-post-${post.slug}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 hover:border-[#D4A017] transition-all duration-500 overflow-hidden rounded-sm"
                >
                  {/* Image */}
                  <div className="aspect-video md:aspect-square overflow-hidden">
                    <img
                      src={post.image_url}
                      alt={title}
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                    />
                  </div>

                  {/* Content */}
                  <div className="md:col-span-2 p-6 flex flex-col justify-between">
                    <div>
                      <Link to={`/blog/${post.slug}`}>
                        <h2 className="text-3xl font-medium text-[#5E0807] mb-3 hover:text-[#D4A017] transition-colors" style={{ fontFamily: 'Playfair Display, serif' }}>
                          {title}
                        </h2>
                      </Link>
                      
                      <p className="text-[#5E0807]/70 mb-4 line-clamp-3">{excerpt}</p>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-[#5E0807]/60">
                        <span className="flex items-center gap-1">
                          <User size={14} />
                          {post.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar size={14} />
                          {new Date(post.created_at).toLocaleDateString('pt-BR')}
                        </span>
                      </div>

                      <Link
                        to={`/blog/${post.slug}`}
                        data-testid={`read-more-btn-${post.slug}`}
                        className="inline-flex items-center gap-2 text-[#D4A017] hover:text-[#C59010] font-medium transition-colors"
                      >
                        {t('blog.readMore')}
                        <ArrowRight size={16} />
                      </Link>
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Blog;
