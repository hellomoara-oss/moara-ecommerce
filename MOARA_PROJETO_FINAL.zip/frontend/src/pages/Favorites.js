import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingCart, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { useCart } from '../contexts/CartContext';

const Favorites = () => {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [favorites, setFavorites] = useState([]);
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const savedFavorites = localStorage.getItem('moara_favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('http://localhost:8001/api/products');
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error('Erro ao buscar produtos:', error);
      }
    };
    fetchProducts();
  }, []);

  const favoriteProducts = products.filter(p => favorites.includes(p.id));

  const toggleFavorite = (productId) => {
    const newFavorites = favorites.includes(productId)
      ? favorites.filter(id => id !== productId)
      : [...favorites, productId];
    
    setFavorites(newFavorites);
    localStorage.setItem('moara_favorites', JSON.stringify(newFavorites));
    toast.success(favorites.includes(productId) ? 'Removido dos favoritos' : 'Adicionado aos favoritos');
  };

  const handleAddToCart = (product) => {
    addToCart(product, 1);
    toast.success(`${product.name_pt} adicionado ao carrinho!`);
  };

  if (favoriteProducts.length === 0) {
    return (
      <div className="min-h-screen bg-[#FAF3E0] pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <Heart className="w-24 h-24 mx-auto text-[#D4A017] opacity-50 mb-6" />
            <h1 className="text-4xl font-serif text-[#5E0807] mb-4">Nenhum Favorito Ainda</h1>
            <p className="text-lg text-[#8C5E5E] mb-8">Clique no coração para adicionar seus produtos favoritos</p>
            <button
              onClick={() => navigate('/collection')}
              className="bg-[#D4A017] text-[#5E0807] px-8 py-3 rounded-full font-serif hover:bg-[#C59010] transition-all"
            >
              Explorar Coleção
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF3E0] pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mb-12"
        >
          <h1 className="text-5xl font-serif text-[#5E0807] mb-2">Meus Favoritos</h1>
          <p className="text-lg text-[#8C5E5E]">{favoriteProducts.length} produto(s) salvo(s)</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {favoriteProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm overflow-hidden hover:border-[#D4A017] transition-all group"
            >
              {/* Imagem */}
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={product.image_url}
                  alt={product.name_pt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <button
                  onClick={() => toggleFavorite(product.id)}
                  className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full hover:bg-white transition-all"
                >
                  <Heart className="w-6 h-6 fill-[#8A1C2B] text-[#8A1C2B]" />
                </button>
              </div>

              {/* Info */}
              <div className="p-6 space-y-4">
                <h3 className="text-2xl font-serif text-[#5E0807]">{product.name_pt}</h3>
                <p className="text-[#8C5E5E] text-sm line-clamp-2">{product.description_pt}</p>
                
                <div className="flex items-center justify-between pt-4 border-t border-[#D4A017]/20">
                  <span className="text-2xl font-serif text-[#D4A017]">
                    R$ {product.price.toFixed(2)}
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleAddToCart(product)}
                      className="bg-[#D4A017] text-[#5E0807] p-2 rounded-full hover:bg-[#C59010] transition-all"
                      title="Adicionar ao carrinho"
                    >
                      <ShoppingCart className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => navigate(`/product/${product.slug}`)}
                      className="border border-[#D4A017] text-[#5E0807] p-2 rounded-full hover:bg-[#FAF3E0] transition-all"
                      title="Ver detalhes"
                    >
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Favorites;
