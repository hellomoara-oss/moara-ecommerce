import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { ExternalLink, ArrowLeft, Leaf, Star, Send } from 'lucide-react';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import ProductReviews from '../components/ProductReviews';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const ProductDetail = () => {
  const { slug } = useParams();
  const { t, i18n } = useTranslation();
  const { user, getAuthHeaders } = useAuth();
  const [product, setProduct] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [reviewStats, setReviewStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);
  const lang = i18n.language;

  useEffect(() => {
    fetchProductData();
  }, [slug]);

  const fetchProductData = async () => {
    try {
      const [productRes, reviewsRes, statsRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/products/${slug}`),
        axios.get(`${BACKEND_URL}/api/reviews/${slug}`),
        axios.get(`${BACKEND_URL}/api/reviews/${slug}/stats`)
      ]);
      setProduct(productRes.data);
      setReviews(reviewsRes.data);
      setReviewStats(statsRes.data);
    } catch (error) {
      console.error('Error fetching product:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!user) {
      toast.error('Faça login para avaliar');
      return;
    }

    setSubmittingReview(true);
    try {
      await axios.post(
        `${BACKEND_URL}/api/reviews`,
        { product_slug: slug, ...newReview },
        { headers: getAuthHeaders() }
      );
      toast.success('Avaliação enviada! +10 pontos de fidelidade');
      setNewReview({ rating: 5, comment: '' });
      fetchProductData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao enviar avaliação');
    } finally {
      setSubmittingReview(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#5E0807]/70">Carregando...</div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-[#5E0807]/70 mb-4">Produto não encontrado</div>
        <Link to="/collection" className="text-[#D4A017] hover:underline">
          Voltar para coleção
        </Link>
      </div>
    );
  }

  const name = lang === 'pt' ? product.name_pt : product.name_en;
  const description = lang === 'pt' ? product.description_pt : product.description_en;
  const benefits = lang === 'pt' ? product.benefits_pt : product.benefits_en;
  const ingredients = lang === 'pt' ? product.ingredients_pt : product.ingredients_en;

  return (
    <div data-testid="product-detail-page" className="min-h-screen py-12 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <Link
          to="/collection"
          data-testid="back-to-collection-btn"
          className="inline-flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] mb-8 transition-colors"
        >
          <ArrowLeft size={20} />
          Voltar
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="aspect-square rounded-sm overflow-hidden border-2 border-[#D4A017]/30">
              <img
                src={product.image_url}
                alt={name}
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Floral corners */}
            <div className="absolute -top-4 -left-4 w-16 h-16 border-l-2 border-t-2 border-[#D4A017]" />
            <div className="absolute -bottom-4 -right-4 w-16 h-16 border-r-2 border-b-2 border-[#D4A017]" />
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 data-testid="product-name" className="text-5xl md:text-6xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
              {name}
            </h1>
            
            {/* Rating */}
            {reviewStats && reviewStats.total_reviews > 0 && (
              <div className="flex items-center gap-2 mb-4">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={18}
                      className={i < Math.round(reviewStats.average_rating) ? 'fill-[#D4A017] text-[#D4A017]' : 'text-[#D4A017]/30'}
                    />
                  ))}
                </div>
                <span className="text-[#5E0807]/70 text-sm">
                  {reviewStats.average_rating} ({reviewStats.total_reviews} {reviewStats.total_reviews === 1 ? 'avaliação' : 'avaliações'})
                </span>
              </div>
            )}
            
            <p className="text-2xl text-[#D4A017] font-medium mb-6">
              R$ {product.price.toFixed(2)}
            </p>

            <p className="text-lg text-[#5E0807]/80 mb-8 leading-relaxed">
              {description}
            </p>

            {/* Buy Button */}
            <a
              href={product.mercado_livre_url}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="buy-mercado-livre-btn"
              className="inline-flex items-center gap-3 bg-[#FFE600] text-[#2D3277] font-bold px-8 py-4 rounded-md hover:brightness-95 transition-all duration-300 mb-12 shadow-lg"
            >
              <img src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/logo__large_plus.png" alt="Mercado Livre" className="h-6" />
              {t('products.buyNow')}
              <ExternalLink size={20} />
            </a>

            {/* Benefits */}
            <div className="mb-8">
              <h3 className="text-2xl font-medium text-[#5E0807] mb-4 flex items-center gap-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                <Leaf className="text-[#D4A017]" size={24} />
                {t('products.benefits')}
              </h3>
              <ul className="space-y-2">
                {benefits.map((benefit, index) => (
                  <li key={index} data-testid={`benefit-${index}`} className="flex items-start gap-2 text-[#5E0807]/80">
                    <span className="text-[#D4A017] mt-1">•</span>
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Ingredients */}
            <div className="mb-8">
              <h3 className="text-2xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                {t('products.ingredients')}
              </h3>
              <div className="flex flex-wrap gap-2">
                {ingredients.map((ingredient, index) => (
                  <span
                    key={index}
                    data-testid={`ingredient-${index}`}
                    className="bg-[#F5E6D3] border border-[#D4A017]/30 px-4 py-2 rounded-full text-sm text-[#5E0807]"
                  >
                    {ingredient}
                  </span>
                ))}
              </div>
            </div>

            {/* How to Prepare */}
            <div className="bg-[#F5E6D3] border border-[#D4A017]/30 p-6 rounded-sm">
              <h3 className="text-xl font-medium text-[#5E0807] mb-3" style={{ fontFamily: 'Playfair Display, serif' }}>
                {t('products.howToPrepare')}
              </h3>
              <ol className="space-y-2 text-[#5E0807]/80">
                <li>1. Ferva 200ml de água</li>
                <li>2. Adicione 1 colher de sopa do chá</li>
                <li>3. Deixe em infusão por 5-7 minutos</li>
                <li>4. Coe e aproveite seu ritual</li>
              </ol>
            </div>
          </motion.div>
        </div>

        {/* Reviews Section */}
        <ProductReviews productId={product.slug} productName={product.name_pt} />
      </div>
    </div>
  );
};

export default ProductDetail;
