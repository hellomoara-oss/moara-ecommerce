import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { ArrowRight, Star, Sparkles } from 'lucide-react';
import axios from 'axios';
import ProductCard from '../components/ProductCard';
// MoonPhases removido conforme solicitado

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Home = () => {
  const { t, i18n } = useTranslation();
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get(`${BACKEND_URL}/api/products?featured=true`);
        setFeaturedProducts(response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const testimonials = [
    {
      name: 'Maria Silva',
      text_pt: 'O Pôr do Sol me ajudou muito com a ansiedade. Recomendo!',
      text_en: 'Sunset helped me a lot with anxiety. I recommend!',
      rating: 5
    },
    {
      name: 'Ana Costa',
      text_pt: 'Lua de Mel é perfeito para dormir melhor. Virei fã!',
      text_en: 'Honey Moon is perfect for better sleep. I became a fan!',
      rating: 5
    },
    {
      name: 'Julia Santos',
      text_pt: 'Chá da Deusa aliviou minhas cólicas. Produto incrível!',
      text_en: 'Goddess Tea relieved my cramps. Amazing product!',
      rating: 5
    }
  ];

  return (
    <div data-testid="home-page" className="scroll-smooth relative">
      {/* Moon Phases removido conforme solicitado */}

      {/* Hero Section */}
      <section data-testid="hero-section" className="relative min-h-[70vh] md:min-h-[85vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <motion.img
            src="https://images.unsplash.com/photo-1742747601406-ce226ba9aecf?w=1600&q=80"
            alt="Moara Hero"
            className="w-full h-full object-cover"
            style={{ y: 0 }}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#FAF3E0]/80 via-[#FAF3E0]/50 to-[#FAF3E0]" />
        </div>

        {/* Mystical Sparkles */}
        <motion.div
          className="absolute top-20 right-20 text-[#D4A017]/30"
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.3, 0.6, 0.3],
            rotate: [0, 90, 0]
          }}
          transition={{ duration: 8, repeat: Infinity }}
        >
          <Sparkles size={48} />
        </motion.div>
        
        <motion.div
          className="absolute bottom-32 left-20 text-[#E8B9B9]/30"
          animate={{
            scale: [1.5, 1, 1.5],
            opacity: [0.2, 0.5, 0.2],
            rotate: [0, -90, 0]
          }}
          transition={{ duration: 10, repeat: Infinity }}
        >
          <Sparkles size={64} />
        </motion.div>

        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <motion.h1
            data-testid="hero-title"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-7xl font-medium text-[#5E0807] mb-6 leading-tight"
            style={{ fontFamily: 'Playfair Display, serif', textShadow: '2px 2px 4px rgba(94, 8, 7, 0.1)' }}
          >
            {t('hero.title')}
          </motion.h1>
          
          <motion.p
            data-testid="hero-subtitle"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl md:text-2xl text-[#5E0807]/80 mb-8"
          >
            {t('hero.subtitle')}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Link
              to="/collection"
              data-testid="hero-cta-btn"
              className="inline-flex items-center gap-2 bg-[#D4A017] text-[#5E0807] px-8 py-4 rounded-full font-medium text-lg hover:bg-[#C59010] transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-2xl relative overflow-hidden group"
            >
              <span className="relative z-10">{t('hero.cta')}</span>
              <ArrowRight size={20} className="relative z-10" />
              {/* Animated shine effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
              />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Categories Section */}
      <section data-testid="categories-section" className="py-20 px-6 md:px-12 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: t('categories.solar'), color: '#8A1C2B', icon: '☀️', slug: 'solar' },
              { name: t('categories.lunar'), color: '#0F1C3A', icon: '🌙', slug: 'lunar' },
              { name: t('categories.divine'), color: '#E8B9B9', icon: '✨', slug: 'divine' }
            ].map((category, index) => (
              <Link
                key={category.slug}
                to={`/collection?category=${category.slug}`}
                data-testid={`category-card-${category.slug}`}
              >
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ scale: 1.03, y: -5 }}
                  className="group relative h-64 rounded-sm overflow-hidden border border-[#D4A017]/30 hover:border-[#D4A017] transition-all duration-500 shadow-lg hover:shadow-2xl"
                  style={{ backgroundColor: category.color }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  
                  {/* Mystical glow on hover */}
                  <motion.div
                    className="absolute inset-0 bg-[#D4A017]/0 group-hover:bg-[#D4A017]/10 transition-all duration-500"
                    animate={{
                      boxShadow: ['0 0 0px rgba(212, 160, 23, 0)', '0 0 30px rgba(212, 160, 23, 0.3)', '0 0 0px rgba(212, 160, 23, 0)']
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  
                  <div className="relative h-full flex flex-col items-center justify-center text-white z-10">
                    <motion.span
                      className="text-7xl mb-4"
                      animate={{
                        scale: [1, 1.1, 1],
                        rotate: [0, 5, -5, 0],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                    >
                      {category.icon}
                    </motion.span>
                    <h3 className="text-3xl font-medium" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {category.name}
                    </h3>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section data-testid="featured-products-section" className="py-20 px-6 md:px-12 bg-[#F5E6D3]">
        <div className="max-w-7xl mx-auto">
          <h2 data-testid="featured-products-title" className="text-4xl md:text-5xl font-medium text-[#5E0807] text-center mb-12" style={{ fontFamily: 'Playfair Display, serif' }}>
            {t('products.featured')}
          </h2>

          {loading ? (
            <div className="text-center text-[#5E0807]/70">Carregando produtos...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link
              to="/collection"
              data-testid="view-all-products-btn"
              className="inline-flex items-center gap-2 border-2 border-[#D4A017] text-[#5E0807] px-8 py-3 rounded-full font-medium hover:bg-[#D4A017]/10 transition-all duration-300"
            >
              Ver Todos os Produtos
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section data-testid="testimonials-section" className="py-20 px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-medium text-[#5E0807] text-center mb-12" style={{ fontFamily: 'Playfair Display, serif' }}>
            Depoimentos
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                data-testid={`testimonial-${index}`}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 p-6 rounded-sm"
              >
                <div className="flex gap-1 mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={16} className="fill-[#D4A017] text-[#D4A017]" />
                  ))}
                </div>
                <p className="text-[#5E0807]/80 mb-4 italic">
                  "{i18n.language === 'pt' ? testimonial.text_pt : testimonial.text_en}"
                </p>
                <p className="text-[#5E0807] font-medium">— {testimonial.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA to Quiz */}
      <section data-testid="quiz-cta-section" className="py-20 px-6 md:px-12 bg-gradient-to-r from-[#E8B9B9] to-[#D4A017]/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-medium text-[#5E0807] mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            Descubra seu chá ideal
          </h2>
          <p className="text-xl text-[#5E0807]/80 mb-8">
            Responda nosso quiz e receba uma recomendação personalizada + 10% de desconto
          </p>
          <Link
            to="/quiz"
            data-testid="quiz-cta-btn"
            className="inline-flex items-center gap-2 bg-[#5E0807] text-[#FAF3E0] px-8 py-4 rounded-full font-medium text-lg hover:bg-[#8A1C2B] transition-all duration-300 hover:scale-105 shadow-lg"
          >
            Fazer Quiz
            <ArrowRight size={20} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
