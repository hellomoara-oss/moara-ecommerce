import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Leaf, Sparkles, Users } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Heart,
      title: 'Cuidado Feminino',
      description: 'Produtos desenvolvidos especificamente para honrar o corpo e ciclos femininos',
      color: '#E8B9B9',
    },
    {
      icon: Leaf,
      title: 'Ingredientes Naturais',
      description: 'Utilizamos apenas ervas e ingredientes 100% naturais e sustentáveis',
      color: '#4A7C59',
    },
    {
      icon: Sparkles,
      title: 'Energia Mística',
      description: 'Cada produto é feito com intenção e energia positiva para sua transformação',
      color: '#D4A017',
    },
    {
      icon: Users,
      title: 'Comunidade',
      description: 'Conectamos mulheres que buscam autocuidado e autoconhecimento',
      color: '#8A1C2B',
    },
  ];

  return (
    <div className="min-h-screen bg-[#FAF3E0]">
      {/* Hero */}
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-6xl font-serif text-[#5E0807] mb-6">Sobre Moara</h1>
            <p className="text-xl text-[#8C5E5E] max-w-3xl mx-auto leading-relaxed">
              Moara é mais do que uma marca de chás e óleos. Somos um movimento de mulheres que acreditam no poder da natureza, 
              na sabedoria ancestral e na importância do autocuidado como ato revolucionário.
            </p>
          </motion.div>

          {/* Missão, Visão, Valores */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            {[
              {
                title: 'Nossa Missão',
                text: 'Empoderar mulheres através de produtos naturais que honram seus ciclos, corpos e espíritos.',
              },
              {
                title: 'Nossa Visão',
                text: 'Ser a marca de referência em bem-estar feminino, conectando tradição e modernidade.',
              },
              {
                title: 'Nossos Valores',
                text: 'Autenticidade, sustentabilidade, inclusão e amor pela vida em todas as suas formas.',
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8"
              >
                <h3 className="text-2xl font-serif text-[#5E0807] mb-4">{item.title}</h3>
                <p className="text-[#8C5E5E] leading-relaxed">{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Valores */}
      <div className="py-20 bg-white/30">
        <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-4xl font-serif text-[#5E0807] text-center mb-16"
          >
            Nossos Pilares
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8 text-center hover:border-[#D4A017] transition-all"
                >
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{ backgroundColor: value.color + '20' }}
                  >
                    <Icon className="w-8 h-8" style={{ color: value.color }} />
                  </div>
                  <h3 className="text-xl font-serif text-[#5E0807] mb-3">{value.title}</h3>
                  <p className="text-[#8C5E5E] text-sm">{value.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* História */}
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-6 md:px-12 lg:px-24">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-8"
          >
            <h2 className="text-4xl font-serif text-[#5E0807] mb-8">Nossa História</h2>

            <div className="space-y-6 text-[#8C5E5E] leading-relaxed">
              <p>
                Moara nasceu de uma conversa entre amigas sobre ciclos menstruais, autocuidado e a falta de produtos que realmente 
                entendessem as necessidades do corpo feminino. O que começou como um projeto pessoal se transformou em uma missão.
              </p>

              <p>
                Cada fórmula foi desenvolvida com pesquisa profunda sobre ervas ancestrais, conhecimento tradicional e ciência moderna. 
                Combinamos o melhor dos dois mundos: a sabedoria das avós com a tecnologia de hoje.
              </p>

              <p>
                Hoje, Moara é mais que um negócio. É uma comunidade de mulheres que se cuidam, se apoiam e se empoderam mutuamente. 
                Cada compra é um voto de confiança em nós e em você mesma.
              </p>

              <p>
                Acreditamos que autocuidado é um ato político. Quando você cuida de si mesma, você se torna mais forte, mais consciente 
                e mais capaz de transformar o mundo ao seu redor.
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      {/* CTA */}
      <div className="py-20 bg-gradient-to-r from-[#D4A017]/10 to-[#8A1C2B]/10">
        <div className="max-w-4xl mx-auto px-6 md:px-12 lg:px-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h2 className="text-4xl font-serif text-[#5E0807] mb-6">Junte-se a Nós</h2>
            <p className="text-lg text-[#8C5E5E] mb-8">
              Faça parte de um movimento de mulheres que escolhem se cuidar, se conhecer e se transformar.
            </p>
            <button className="bg-[#D4A017] text-[#5E0807] px-8 py-4 rounded-full font-serif hover:bg-[#C59010] transition-all transform hover:scale-105">
              Explorar Coleção
            </button>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default About;
