import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Check, Package, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Subscriptions = () => {
  const { t, i18n } = useTranslation();
  const { user, getAuthHeaders } = useAuth();
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedPlan, setSelectedPlan] = useState('monthly');
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const lang = i18n.language;

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [plansRes, productsRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/subscriptions/plans`),
        axios.get(`${BACKEND_URL}/api/products`)
      ]);
      setPlans(plansRes.data.plans);
      setProducts(productsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleProduct = (slug) => {
    if (selectedProducts.includes(slug)) {
      setSelectedProducts(selectedProducts.filter(s => s !== slug));
    } else {
      setSelectedProducts([...selectedProducts, slug]);
    }
  };

  const calculateTotal = () => {
    const selectedProds = products.filter(p => selectedProducts.includes(p.slug));
    const baseTotal = selectedProds.reduce((sum, p) => sum + p.price, 0);
    const plan = plans.find(p => p.id === selectedPlan);
    const discount = plan?.discount || 0;
    return baseTotal * (1 - discount / 100);
  };

  const handleSubscribe = async () => {
    if (!user) {
      toast.error('Faça login para assinar');
      return;
    }

    if (selectedProducts.length === 0) {
      toast.error('Selecione ao menos um produto');
      return;
    }

    try {
      await axios.post(
        `${BACKEND_URL}/api/subscriptions`,
        { plan: selectedPlan, products: selectedProducts },
        { headers: getAuthHeaders() }
      );
      toast.success('Assinatura criada com sucesso! +50 pontos de fidelidade');
      navigate('/profile');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao criar assinatura');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#5E0807]/70">Carregando...</div>
      </div>
    );
  }

  return (
    <div data-testid="subscriptions-page" className="min-h-screen py-12 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Sparkles className="mx-auto text-[#D4A017] mb-4" size={48} />
          <h1 className="text-5xl md:text-6xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            {lang === 'pt' ? 'Assinatura de Chás' : 'Tea Subscription'}
          </h1>
          <p className="text-xl text-[#5E0807]/70 max-w-2xl mx-auto">
            {lang === 'pt'
              ? 'Receba seus chás favoritos todo mês com descontos exclusivos'
              : 'Receive your favorite teas every month with exclusive discounts'}
          </p>
        </div>

        {/* Plans */}
        <div className="mb-12">
          <h2 className="text-2xl font-medium text-[#5E0807] mb-6 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
            {lang === 'pt' ? 'Escolha seu Plano' : 'Choose Your Plan'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <motion.button
                key={plan.id}
                data-testid={`plan-${plan.id}`}
                onClick={() => setSelectedPlan(plan.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`p-6 rounded-sm border-2 transition-all ${
                  selectedPlan === plan.id
                    ? 'border-[#D4A017] bg-[#D4A017]/10'
                    : 'border-[#D4A017]/30 bg-white/50 hover:border-[#D4A017]/50'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-2xl font-medium text-[#5E0807]" style={{ fontFamily: 'Playfair Display, serif' }}>
                    {lang === 'pt' ? plan.name : plan.name_en}
                  </h3>
                  {plan.discount > 0 && (
                    <span className="bg-[#D4A017] text-[#5E0807] px-3 py-1 rounded-full text-sm font-bold">
                      -{plan.discount}%
                    </span>
                  )}
                </div>
                <p className="text-[#5E0807]/70 mb-2">{lang === 'pt' ? plan.duration : plan.duration_en}</p>
                <p className="text-sm text-[#5E0807]/60">{lang === 'pt' ? plan.description_pt : plan.description_en}</p>
                {selectedPlan === plan.id && (
                  <div className="mt-4 flex items-center justify-center">
                    <Check className="text-[#D4A017]" size={24} />
                  </div>
                )}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Products Selection */}
        <div className="mb-12">
          <h2 className="text-2xl font-medium text-[#5E0807] mb-6 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
            {lang === 'pt' ? 'Escolha seus Chás' : 'Choose Your Teas'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {products.map((product) => (
              <motion.button
                key={product.slug}
                data-testid={`product-${product.slug}`}
                onClick={() => toggleProduct(product.slug)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`text-left p-4 rounded-sm border-2 transition-all ${
                  selectedProducts.includes(product.slug)
                    ? 'border-[#D4A017] bg-[#D4A017]/10'
                    : 'border-[#D4A017]/30 bg-white/50 hover:border-[#D4A017]/50'
                }`}
              >
                <div className="aspect-square rounded-sm overflow-hidden mb-3">
                  <img src={product.image_url} alt={lang === 'pt' ? product.name_pt : product.name_en} className="w-full h-full object-cover" />
                </div>
                <h3 className="text-lg font-medium text-[#5E0807] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                  {lang === 'pt' ? product.name_pt : product.name_en}
                </h3>
                <p className="text-[#D4A017] font-bold mb-2">R$ {product.price.toFixed(2)}</p>
                {selectedProducts.includes(product.slug) && (
                  <div className="flex items-center gap-2 text-[#D4A017] text-sm font-medium">
                    <Check size={16} />
                    Selecionado
                  </div>
                )}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Summary */}
        {selectedProducts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-[#E8B9B9] to-[#D4A017]/30 border-2 border-[#D4A017] p-8 rounded-sm"
          >
            <div className="max-w-2xl mx-auto">
              <h3 className="text-2xl font-medium text-[#5E0807] mb-4 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
                Resumo da Assinatura
              </h3>
              
              <div className="bg-white/80 p-6 rounded-sm mb-6">
                <div className="flex justify-between mb-2">
                  <span className="text-[#5E0807]">Plano:</span>
                  <span className="font-medium text-[#5E0807]">
                    {plans.find(p => p.id === selectedPlan)?.[lang === 'pt' ? 'name' : 'name_en']}
                  </span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-[#5E0807]">Produtos selecionados:</span>
                  <span className="font-medium text-[#5E0807]">{selectedProducts.length}</span>
                </div>
                {plans.find(p => p.id === selectedPlan)?.discount > 0 && (
                  <div className="flex justify-between mb-2">
                    <span className="text-[#5E0807]">Desconto:</span>
                    <span className="font-medium text-green-600">
                      -{plans.find(p => p.id === selectedPlan)?.discount}%
                    </span>
                  </div>
                )}
                <div className="border-t border-[#D4A017]/30 pt-2 mt-2 flex justify-between">
                  <span className="text-lg font-medium text-[#5E0807]">Total mensal:</span>
                  <span className="text-2xl font-bold text-[#D4A017]">R$ {calculateTotal().toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={handleSubscribe}
                data-testid="subscribe-btn"
                className="w-full bg-[#5E0807] text-[#FAF3E0] py-4 rounded-full font-medium text-lg hover:bg-[#8A1C2B] transition-all duration-300 flex items-center justify-center gap-2"
              >
                <Package size={20} />
                {user ? 'Assinar Agora' : 'Faça Login para Assinar'}
              </button>

              <p className="text-center text-sm text-[#5E0807]/70 mt-4">
                ✨ Ganhe 50 pontos de fidelidade ao assinar!
              </p>
            </div>
          </motion.div>
        )}

        {/* Benefits */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              title_pt: 'Descontos Progressivos',
              title_en: 'Progressive Discounts',
              desc_pt: 'Quanto mais tempo assinado, maior o desconto',
              desc_en: 'The longer you subscribe, the bigger the discount'
            },
            {
              title_pt: 'Flexibilidade Total',
              title_en: 'Total Flexibility',
              desc_pt: 'Escolha seus chás e cancele quando quiser',
              desc_en: 'Choose your teas and cancel anytime'
            },
            {
              title_pt: 'Pontos em Dobro',
              title_en: 'Double Points',
              desc_pt: 'Assinantes ganham pontos de fidelidade em dobro',
              desc_en: 'Subscribers earn double loyalty points'
            }
          ].map((benefit, index) => (
            <div key={index} className="bg-white/50 border border-[#D4A017]/30 p-6 rounded-sm text-center">
              <h4 className="text-lg font-medium text-[#5E0807] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                {lang === 'pt' ? benefit.title_pt : benefit.title_en}
              </h4>
              <p className="text-sm text-[#5E0807]/70">
                {lang === 'pt' ? benefit.desc_pt : benefit.desc_en}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Subscriptions;
