import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { Trash2, Plus, Minus, ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';

const Cart = () => {
  const navigate = useNavigate();
  const { cartItems, removeFromCart, updateQuantity, getSubtotal, getShippingCost, getTotal, clearCart } = useCart();

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-[#FAF3E0] pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <ShoppingCart className="w-24 h-24 mx-auto text-[#D4A017] opacity-50 mb-6" />
            <h1 className="text-4xl font-serif text-[#5E0807] mb-4">Seu carrinho está vazio</h1>
            <p className="text-lg text-[#8C5E5E] mb-8">Descubra nossos produtos místicos e comece seu ritual de autocuidado</p>
            <button
              onClick={() => navigate('/collection')}
              className="bg-[#D4A017] text-[#5E0807] px-8 py-3 rounded-full font-serif hover:bg-[#C59010] transition-all"
            >
              Explorar Coleção
            </button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF3E0] pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mb-12"
        >
          <h1 className="text-5xl font-serif text-[#5E0807] mb-2">Seu Ritual</h1>
          <p className="text-lg text-[#8C5E5E]">Revise seus produtos antes de prosseguir</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Produtos */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8 space-y-6"
            >
              {cartItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex gap-6 pb-6 border-b border-[#D4A017]/20 last:border-0"
                >
                  {/* Imagem */}
                  <div className="w-24 h-24 rounded-sm overflow-hidden flex-shrink-0">
                    <img
                      src={item.image_url}
                      alt={item.name_pt}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Detalhes */}
                  <div className="flex-1">
                    <h3 className="text-xl font-serif text-[#5E0807] mb-1">{item.name_pt}</h3>
                    <p className="text-sm text-[#8C5E5E] mb-3">{item.description_pt}</p>
                    <p className="text-lg font-serif text-[#D4A017]">R$ {item.price.toFixed(2)}</p>
                  </div>

                  {/* Quantidade e Ações */}
                  <div className="flex flex-col items-end justify-between">
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-[#8A1C2B] hover:text-[#5E0807] transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>

                    <div className="flex items-center gap-2 border border-[#D4A017]/30 rounded-full px-3 py-1">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="text-[#8C5E5E] hover:text-[#5E0807]"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-8 text-center font-serif text-[#5E0807]">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="text-[#8C5E5E] hover:text-[#5E0807]"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>

                    <p className="text-lg font-serif text-[#5E0807]">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Resumo */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-1"
          >
            <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8 sticky top-32 space-y-6">
              <h2 className="text-2xl font-serif text-[#5E0807]">Resumo do Pedido</h2>

              <div className="space-y-4 pb-6 border-b border-[#D4A017]/20">
                <div className="flex justify-between text-[#8C5E5E]">
                  <span>Subtotal:</span>
                  <span>R$ {getSubtotal().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#8C5E5E]">
                  <span>Frete:</span>
                  <span>R$ {getShippingCost().toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between text-xl font-serif text-[#5E0807]">
                <span>Total:</span>
                <span>R$ {getTotal().toFixed(2)}</span>
              </div>

              <button
                onClick={() => navigate('/checkout')}
                className="w-full bg-[#D4A017] text-[#5E0807] py-3 rounded-full font-serif hover:bg-[#C59010] transition-all transform hover:scale-105"
              >
                Prosseguir para Checkout
              </button>

              <button
                onClick={() => navigate('/collection')}
                className="w-full border border-[#D4A017] text-[#5E0807] py-3 rounded-full font-serif hover:bg-[#FAF3E0] transition-all"
              >
                Continuar Comprando
              </button>

              <button
                onClick={clearCart}
                className="w-full text-[#8A1C2B] py-3 rounded-full font-serif hover:bg-[#FAF3E0] transition-all text-sm"
              >
                Limpar Carrinho
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
