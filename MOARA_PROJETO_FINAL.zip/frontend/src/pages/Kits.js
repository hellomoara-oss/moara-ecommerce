import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Package, Check, Plus, Minus, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Kits = () => {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [kitType, setKitType] = useState('custom'); // 'custom' ou 'preset'
  const [loading, setLoading] = useState(true);
  const lang = i18n.language;

  // Kits prontos
  const presetKits = [
    {
      id: 'ritual-completo',
      name_pt: 'Ritual Completo',
      name_en: 'Complete Ritual',
      description_pt: 'Kit completo para autocuidado: 2 chás + 1 óleo capilar + 1 óleo corporal',
      description_en: 'Complete self-care kit: 2 teas + 1 hair oil + 1 body oil',
      products: ['por-do-sol', 'lua-de-mel', 'oleo-selvagem', 'oleo-corporal-lua-nova'],
      discount: 15,
      price: 170,
      emoji: '✨'
    },
    {
      id: 'ciclo-lunar',
      name_pt: 'Ciclo Lunar',
      name_en: 'Lunar Cycle',
      description_pt: 'Acompanhe todas as fases: 2 chás lunares + óleo corporal',
      description_en: 'Follow all phases: 2 lunar teas + body oil',
      products: ['lua-de-mel', 'cha-donzela', 'oleo-corporal-lua-nova'],
      discount: 12,
      price: 110,
      emoji: '🌙'
    },
    {
      id: 'feminino-sagrado',
      name_pt: 'Feminino Sagrado',
      name_en: 'Sacred Feminine',
      description_pt: 'Cuidado uterino e empoderamento: Chá da Deusa + Chá Donzela + Óleo Corporal',
      description_en: 'Uterine care and empowerment: Goddess Tea + Maiden Tea + Body Oil',
      products: ['cha-da-deusa', 'cha-donzela', 'oleo-corporal-lua-nova'],
      discount: 10,
      price: 118,
      emoji: '🌸'
    },
    {
      id: 'beleza-natural',
      name_pt: 'Beleza Natural',
      name_en: 'Natural Beauty',
      description_pt: 'Cuidados externos: Óleo Selvagem + Óleo Corporal + Chá Pôr do Sol',
      description_en: 'External care: Wild Oil + Body Oil + Sunset Tea',
      products: ['oleo-selvagem', 'oleo-corporal-lua-nova', 'por-do-sol'],
      discount: 10,
      price: 125,
      emoji: '💆‍♀️'
    }
  ];

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/products`);
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleProduct = (slug) => {
    if (selectedProducts.includes(slug)) {
      setSelectedProducts(selectedProducts.filter(s => s !== slug));
    } else {
      if (selectedProducts.length < 4) {
        setSelectedProducts([...selectedProducts, slug]);
      } else {
        toast.info('Máximo de 4 produtos por kit');
      }
    }
  };

  const selectPresetKit = (kit) => {
    setSelectedProducts(kit.products);
    setKitType('preset');
    toast.success(`Kit "${kit.name_pt}" selecionado!`);
  };

  const calculateTotal = () => {
    const selectedProds = products.filter(p => selectedProducts.includes(p.slug));
    const baseTotal = selectedProds.reduce((sum, p) => sum + p.price, 0);
    
    // Desconto progressivo por quantidade
    let discount = 0;
    if (selectedProducts.length === 2) discount = 5;
    if (selectedProducts.length === 3) discount = 10;
    if (selectedProducts.length === 4) discount = 15;
    
    return {
      base: baseTotal,
      discount,
      final: baseTotal * (1 - discount / 100)
    };
  };

  const handleCheckout = () => {
    if (selectedProducts.length === 0) {
      toast.error('Selecione ao menos um produto');
      return;
    }
    
    toast.success('Redirecionando para Mercado Livre...');
    // Aqui você pode redirecionar para um link específico do ML
    window.open('https://www.mercadolivre.com.br', '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#5E0807]/70">Carregando...</div>
      </div>
    );
  }

  const totals = calculateTotal();

  return (
    <div data-testid="kits-page" className="min-h-screen py-12 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Sparkles className="mx-auto text-[#D4A017] mb-4" size={48} />
          <h1 className="text-5xl md:text-6xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            {lang === 'pt' ? 'Monte Seu Kit Moara' : 'Build Your Moara Kit'}
          </h1>
          <p className="text-xl text-[#5E0807]/70">
            {lang === 'pt' 
              ? 'Crie seu ritual personalizado ou escolha um kit pronto' 
              : 'Create your personalized ritual or choose a ready kit'}
          </p>
        </div>

        {/* Kits Prontos */}
        <div className="mb-16">
          <h2 className="text-3xl font-medium text-[#5E0807] mb-8 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
            {lang === 'pt' ? 'Kits Prontos' : 'Ready Kits'}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {presetKits.map((kit) => (
              <motion.div
                key={kit.id}
                data-testid={`preset-kit-${kit.id}`}
                whileHover={{ scale: 1.03, y: -5 }}
                className="bg-gradient-to-br from-white/80 to-[#FAF3E0]/80 border-2 border-[#D4A017]/30 hover:border-[#D4A017] p-6 rounded-lg transition-all duration-300 cursor-pointer"
                onClick={() => selectPresetKit(kit)}
              >
                <div className="text-5xl mb-3 text-center">{kit.emoji}</div>
                <h3 className="text-xl font-medium text-[#5E0807] mb-2 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
                  {lang === 'pt' ? kit.name_pt : kit.name_en}
                </h3>
                <p className="text-sm text-[#5E0807]/70 mb-4 text-center">
                  {lang === 'pt' ? kit.description_pt : kit.description_en}
                </p>
                <div className="text-center mb-3">
                  <span className="inline-block bg-[#D4A017] text-[#5E0807] px-3 py-1 rounded-full text-sm font-bold">
                    -{kit.discount}% OFF
                  </span>
                </div>
                <div className="text-center">
                  <span className="text-2xl font-bold text-[#D4A017]">R$ {kit.price}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Divisor */}
        <div className="relative mb-16">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-[#D4A017]/30"></div>
          </div>
          <div className="relative flex justify-center">
            <span className="bg-[#FAF3E0] px-6 text-lg text-[#5E0807]/70 font-medium">ou</span>
          </div>
        </div>

        {/* Monte Seu Kit */}
        <div>
          <h2 className="text-3xl font-medium text-[#5E0807] mb-8 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
            {lang === 'pt' ? 'Monte Seu Próprio Kit' : 'Build Your Own Kit'}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {products.map((product) => {
              const isSelected = selectedProducts.includes(product.slug);
              const name = lang === 'pt' ? product.name_pt : product.name_en;
              
              return (
                <motion.div
                  key={product.slug}
                  data-testid={`product-${product.slug}`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => toggleProduct(product.slug)}
                  className={`relative p-4 rounded-lg border-2 transition-all duration-300 cursor-pointer ${
                    isSelected
                      ? 'border-[#D4A017] bg-[#D4A017]/10 shadow-lg'
                      : 'border-[#D4A017]/30 bg-white/50 hover:border-[#D4A017]/50'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-2 right-2 bg-[#D4A017] text-white rounded-full p-1">
                      <Check size={16} />
                    </div>
                  )}
                  
                  <div className="aspect-square rounded-lg overflow-hidden mb-3">
                    <img src={product.image_url} alt={name} className="w-full h-full object-cover" />
                  </div>
                  
                  <h3 className="text-lg font-medium text-[#5E0807] mb-2" style={{ fontFamily: 'Playfair Display, serif' }}>
                    {name}
                  </h3>
                  
                  <p className="text-[#D4A017] font-bold">R$ {product.price.toFixed(2)}</p>
                </motion.div>
              );
            })}
          </div>

          {/* Summary */}
          {selectedProducts.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-br from-[#E8B9B9]/30 to-[#D4A017]/20 border-2 border-[#D4A017] p-8 rounded-lg max-w-2xl mx-auto"
            >
              <h3 className="text-2xl font-medium text-[#5E0807] mb-6 text-center" style={{ fontFamily: 'Playfair Display, serif' }}>
                Resumo do Seu Kit
              </h3>
              
              <div className="bg-white/80 p-6 rounded-lg mb-6">
                <div className="flex justify-between mb-3">
                  <span className="text-[#5E0807]">Produtos selecionados:</span>
                  <span className="font-medium text-[#5E0807]">{selectedProducts.length}</span>
                </div>
                <div className="flex justify-between mb-3">
                  <span className="text-[#5E0807]">Subtotal:</span>
                  <span className="font-medium text-[#5E0807]">R$ {totals.base.toFixed(2)}</span>
                </div>
                {totals.discount > 0 && (
                  <div className="flex justify-between mb-3">
                    <span className="text-[#5E0807]">Desconto ({selectedProducts.length} produtos):</span>
                    <span className="font-medium text-green-600">-{totals.discount}%</span>
                  </div>
                )}
                <div className="border-t border-[#D4A017]/30 pt-3 mt-3 flex justify-between">
                  <span className="text-lg font-medium text-[#5E0807]">Total:</span>
                  <span className="text-2xl font-bold text-[#D4A017]">R$ {totals.final.toFixed(2)}</span>
                </div>
              </div>

              <div className="text-center text-sm text-[#5E0807]/70 mb-6">
                {selectedProducts.length < 4 && (
                  <p>💡 Adicione mais produtos para aumentar o desconto! (Máx 4)</p>
                )}
                {selectedProducts.length === 4 && (
                  <p>✨ Desconto máximo alcançado! (15% OFF)</p>
                )}
              </div>

              <button
                onClick={handleCheckout}
                data-testid="checkout-kit-btn"
                className="w-full bg-[#FFE600] text-[#2D3277] font-bold py-4 rounded-full hover:brightness-95 transition-all duration-300 flex items-center justify-center gap-2 shadow-lg"
              >
                <Package size={20} />
                Comprar Kit no Mercado Livre
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Kits;
