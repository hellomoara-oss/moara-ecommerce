import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Shuffle } from 'lucide-react';
import { toast } from 'sonner';

const Oracle = () => {
  const [selectedCard, setSelectedCard] = useState(null);
  const [isFlipping, setIsFlipping] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);

  const oracleCards = [
    {
      id: 1,
      name: 'Renovação',
      symbol: '🌱',
      message: 'É hora de começar algo novo. Deixe ir o que não serve mais e abra espaço para transformação.',
      color: '#4A7C59',
    },
    {
      id: 2,
      name: 'Proteção',
      symbol: '🧿',
      message: 'Você está protegida. Confie na sua intuição e na energia das ervas que a cercam neste momento.',
      color: '#0F1C3A',
    },
    {
      id: 3,
      name: 'Abundância',
      symbol: '✨',
      message: 'A abundância flui em sua vida. Reconheça as bênçãos ao seu redor e compartilhe generosamente.',
      color: '#D4A017',
    },
    {
      id: 4,
      name: 'Cura',
      symbol: '💚',
      message: 'Permita-se curar. Seja gentil consigo mesma e confie no processo de transformação.',
      color: '#E8B9B9',
    },
    {
      id: 5,
      name: 'Sabedoria',
      symbol: '📜',
      message: 'Sua sabedoria interna é forte. Ouça a voz do seu coração e confie no seu conhecimento ancestral.',
      color: '#8A1C2B',
    },
    {
      id: 6,
      name: 'Conexão',
      symbol: '🌸',
      message: 'Você está conectada com tudo ao seu redor. Cultive relacionamentos significativos.',
      color: '#C59010',
    },
    {
      id: 7,
      name: 'Equilíbrio',
      symbol: '⚖️',
      message: 'Busque o equilíbrio em todas as áreas da sua vida. Harmonia traz paz.',
      color: '#5E0807',
    },
    {
      id: 8,
      name: 'Coragem',
      symbol: '🔥',
      message: 'Você tem coragem dentro de si. É hora de agir com confiança e determinação.',
      color: '#8C5E5E',
    },
  ];

  const handleDrawCard = () => {
    setIsFlipping(true);
    const randomIndex = Math.floor(Math.random() * oracleCards.length);
    setTimeout(() => {
      setSelectedCard(oracleCards[randomIndex]);
      setIsFlipping(false);
      setHasDrawn(true);
      toast.success('Sua carta foi revelada!');
    }, 600);
  };

  const handleReset = () => {
    setSelectedCard(null);
    setHasDrawn(false);
    setIsFlipping(false);
  };

  return (
    <div className="min-h-screen bg-[#FAF3E0] pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 text-[#D4A017]" />
            <h1 className="text-5xl font-serif text-[#5E0807]">O Oráculo Moara</h1>
            <Sparkles className="w-8 h-8 text-[#D4A017]" />
          </div>
          <p className="text-lg text-[#8C5E5E] max-w-2xl mx-auto">
            Deixe a sabedoria ancestral guiar você. Tire uma carta e receba uma mensagem especial para este momento.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Área de Cartas */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center space-y-8"
          >
            {/* Carta Principal */}
            <div className="relative h-96 w-64">
              <AnimatePresence mode="wait">
                {!hasDrawn ? (
                  <motion.div
                    key="back"
                    initial={{ opacity: 0, rotateY: 90 }}
                    animate={{ opacity: 1, rotateY: 0 }}
                    exit={{ opacity: 0, rotateY: -90 }}
                    transition={{ duration: 0.6 }}
                    onClick={handleDrawCard}
                    className="absolute inset-0 bg-gradient-to-br from-[#D4A017] to-[#8A1C2B] rounded-lg shadow-2xl cursor-pointer flex items-center justify-center group hover:shadow-3xl transition-all transform hover:scale-105"
                  >
                    <div className="text-center">
                      <Sparkles className="w-16 h-16 text-white mx-auto mb-4 group-hover:animate-spin" />
                      <p className="text-white font-serif text-xl">Clique para revelar</p>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="front"
                    initial={{ opacity: 0, rotateY: 90 }}
                    animate={{ opacity: 1, rotateY: 0 }}
                    exit={{ opacity: 0, rotateY: -90 }}
                    transition={{ duration: 0.6 }}
                    className="absolute inset-0 bg-white rounded-lg shadow-2xl p-8 flex flex-col items-center justify-center border-4"
                    style={{ borderColor: selectedCard?.color }}
                  >
                    <div
                      className="text-6xl mb-4"
                      style={{ filter: 'drop-shadow(0 0 10px rgba(212, 160, 23, 0.5))' }}
                    >
                      {selectedCard?.symbol}
                    </div>
                    <h2 className="text-3xl font-serif text-[#5E0807] mb-4 text-center">
                      {selectedCard?.name}
                    </h2>
                    <p className="text-center text-[#8C5E5E] text-sm leading-relaxed">
                      {selectedCard?.message}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Botões */}
            <div className="flex gap-4">
              {hasDrawn && (
                <motion.button
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  onClick={handleReset}
                  className="flex items-center gap-2 bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-serif hover:bg-[#C59010] transition-all"
                >
                  <Shuffle className="w-5 h-5" />
                  Tirar Outra Carta
                </motion.button>
              )}
              {!hasDrawn && (
                <motion.button
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  onClick={handleDrawCard}
                  disabled={isFlipping}
                  className="flex items-center gap-2 bg-[#D4A017] text-[#5E0807] px-8 py-4 rounded-full font-serif hover:bg-[#C59010] transition-all disabled:opacity-50"
                >
                  <Sparkles className="w-5 h-5" />
                  Revelar Minha Carta
                </motion.button>
              )}
            </div>
          </motion.div>

          {/* Informações */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-8"
          >
            <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8">
              <h2 className="text-3xl font-serif text-[#5E0807] mb-6">Como Usar o Oráculo</h2>
              <ol className="space-y-4 text-[#8C5E5E]">
                <li className="flex gap-4">
                  <span className="font-serif text-[#D4A017] text-xl flex-shrink-0">1.</span>
                  <span>Respire profundamente e concentre-se na sua intenção</span>
                </li>
                <li className="flex gap-4">
                  <span className="font-serif text-[#D4A017] text-xl flex-shrink-0">2.</span>
                  <span>Clique na carta para revelar sua mensagem</span>
                </li>
                <li className="flex gap-4">
                  <span className="font-serif text-[#D4A017] text-xl flex-shrink-0">3.</span>
                  <span>Reflita sobre o significado e como se aplica à sua vida</span>
                </li>
                <li className="flex gap-4">
                  <span className="font-serif text-[#D4A017] text-xl flex-shrink-0">4.</span>
                  <span>Tire outra carta se desejar mais orientação</span>
                </li>
              </ol>
            </div>

            <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-8">
              <h3 className="text-2xl font-serif text-[#5E0807] mb-4">Sobre o Oráculo</h3>
              <p className="text-[#8C5E5E] leading-relaxed">
                O Oráculo Moara combina sabedoria ancestral com a energia das ervas místicas. Cada carta representa um aspecto da jornada feminina e da transformação pessoal. Use-o como ferramenta de reflexão e autoconhecimento.
              </p>
            </div>

            <div className="bg-gradient-to-br from-[#D4A017]/10 to-[#8A1C2B]/10 border border-[#D4A017]/30 rounded-sm p-8">
              <p className="text-[#5E0807] font-serif italic text-center">
                "A sabedoria que você busca já existe dentro de você. O oráculo apenas a revela."
              </p>
            </div>
          </motion.div>
        </div>

        {/* Grid de Todas as Cartas */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-20"
        >
          <h2 className="text-3xl font-serif text-[#5E0807] mb-8 text-center">Todas as Cartas</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {oracleCards.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-6 text-center hover:border-[#D4A017] transition-all transform hover:scale-105"
                style={{ borderTopColor: card.color, borderTopWidth: '4px' }}
              >
                <div className="text-4xl mb-3">{card.symbol}</div>
                <h3 className="font-serif text-[#5E0807] text-lg">{card.name}</h3>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Oracle;
