import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Flame, Droplet, Wind, Sparkles, Heart, Coffee, AlertTriangle } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const Ritual = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const [expandedStep, setExpandedStep] = useState(0);

  const ritualSteps = [
    {
      id: 1,
      title_pt: 'Preparação do Espaço',
      title_en: 'Space Preparation',
      icon: Wind,
      time: '5 min',
      desc_pt: 'Crie um ambiente sagrado para seu ritual',
      desc_en: 'Create a sacred space for your ritual',
      details_pt: [
        'Escolha um local tranquilo e confortável',
        'Abra as janelas para renovar a energia',
        'Acenda uma vela ou incenso (opcional)',
        'Desligue o celular ou coloque no silencioso',
        'Coloque uma música relaxante de fundo'
      ],
      details_en: [
        'Choose a quiet and comfortable place',
        'Open windows to renew energy',
        'Light a candle or incense (optional)',
        'Turn off your phone or silence it',
        'Put relaxing music in the background'
      ],
      color: '#4A7C59'
    },
    {
      id: 2,
      title_pt: 'Intenção',
      title_en: 'Intention',
      icon: Heart,
      time: '2 min',
      desc_pt: 'Defina sua intenção para este ritual',
      desc_en: 'Set your intention for this ritual',
      details_pt: [
        'Sente-se confortavelmente e respire profundamente 3 vezes',
        'Coloque a mão no coração ou no ventre',
        'Mentalize: "Este momento é meu, eu me permito cuidar de mim"',
        'Pense no que você deseja para este momento',
        'Sussurre sua intenção em voz alta ou mentalmente'
      ],
      details_en: [
        'Sit comfortably and breathe deeply 3 times',
        'Place your hand on your heart or womb',
        'Mentalize: "This moment is mine, I allow myself to take care of me"',
        'Think about what you want for this moment',
        'Whisper your intention aloud or mentally'
      ],
      color: '#8A1C2B'
    },
    {
      id: 3,
      title_pt: 'Aquecimento da Água',
      title_en: 'Water Heating',
      icon: Flame,
      time: '5-10 min',
      desc_pt: 'Prepare a água com atenção e presença',
      desc_en: 'Prepare water with attention and presence',
      details_pt: [
        'Aqueça água filtrada até começar a liberar vapor (80-90°C)',
        'Não precisa ferver completamente para não "queimar" as ervas',
        'Enquanto aquece, observe o vapor subindo e se acalme',
        'Imagine a energia da água se tornando pura e viva',
        'Escute o som suave da água aquecendo'
      ],
      details_en: [
        'Heat filtered water until it starts releasing steam (80-90°C)',
        'No need to boil completely to avoid "burning" the herbs',
        'While heating, observe the steam rising and calm down',
        'Imagine the water\'s energy becoming pure and alive',
        'Listen to the soft sound of water heating'
      ],
      color: '#D4A017'
    },
    {
      id: 4,
      title_pt: 'Preparação da Magia',
      title_en: 'Magic Preparation',
      icon: Droplet,
      time: '3-15 min',
      desc_pt: 'Prepare seu chá, banho ou compressa',
      desc_en: 'Prepare your tea, bath or compress',
      details_pt: [
        'Adicione uma colher de sopa do blend escolhido',
        'Despeje a água quente lentamente sobre as ervas',
        'Tampe imediatamente para manter os óleos essenciais',
        'Deixe em infusão por 5 a 10 minutos (chá) ou 15 min (banho)',
        'Observe as cores e sinta o aroma ancestral'
      ],
      details_en: [
        'Add a tablespoon of the chosen blend',
        'Pour hot water slowly over the herbs',
        'Cover immediately to keep the essential oils',
        'Let it infuse for 5 to 10 minutes (tea) or 15 min (bath)',
        'Observe the colors and feel the ancestral aroma'
      ],
      color: '#0F1C3A'
    },
    {
      id: 5,
      title_pt: 'Conexão e Consumo',
      title_en: 'Connection and Consumption',
      icon: Sparkles,
      time: '15-45 min',
      desc_pt: 'Aproveite o momento de conexão com sua essência',
      desc_en: 'Enjoy the moment of connection with your essence',
      details_pt: [
        'Segure sua xícara com ambas as mãos sentindo o calor',
        'Beba em pequenos goles, sentindo o sabor da natureza',
        'Se for banho de assento, sente-se pelo tempo que precisar',
        'Se for compressa, aplique no ventre e relaxe',
        'Agradeça à terra e a você mesma por este cultivo'
      ],
      details_en: [
        'Hold your cup with both hands feeling the heat',
        'Drink in small sips, feeling the taste of nature',
        'If it\'s a sitz bath, sit for as long as you need',
        'If it\'s a compress, apply to the womb and relax',
        'Thank the earth and yourself for this cultivation'
      ],
      color: '#E8B9B9'
    }
  ];

  const benefits = [
    { title_pt: 'Herbalismo', title_en: 'Herbalism', desc_pt: 'Sabedoria ancestral das plantas', desc_en: 'Ancestral plant wisdom', icon: '🌿' },
    { title_pt: 'Bruxaria Natural', title_en: 'Natural Witchcraft', desc_pt: 'Magia na sua forma mais pura', desc_en: 'Magic in its purest form', icon: '🔮' },
    { title_pt: 'Fitoenergética', title_en: 'Phytoenergetics', desc_pt: 'A força viva das ervas', desc_en: 'The living force of herbs', icon: '✨' },
    { title_pt: 'Autocuidado', title_en: 'Self-Care', desc_pt: 'Alternativa consciente e natural', desc_en: 'Conscious and natural alternative', icon: '🌸' }
  ];

  const ritualMethods = [
    {
      icon: Coffee,
      title_pt: 'Infusão (Chá)',
      title_en: 'Infusion (Tea)',
      desc_pt: 'Aqueça a água (não ferver), adicione uma colher de sopa, tampe e espere alguns minutos. Adoce com mel se desejar.',
      desc_en: 'Heat water (do not boil), add a tablespoon, cover and wait a few minutes. Sweeten with honey if desired.'
    },
    {
      icon: Droplet,
      title_pt: 'Banho de Assento',
      title_en: 'Sitz Bath',
      desc_pt: '1 colher de sopa para 1,5L de água quente. Infusão por 10 a 15 min. Sente por quanto tempo precisar.',
      desc_en: '1 tablespoon for 1.5L of hot water. Infusion for 10 to 15 min. Sit for as long as you need.'
    },
    {
      icon: Heart,
      title_pt: 'Compressa Morna',
      title_en: 'Warm Compress',
      desc_pt: '500ml água + 2 colheres de sopa. Molhe uma toalha na infusão e coloque no baixo ventre para cólicas fortes.',
      desc_en: '500ml water + 2 tablespoons. Soak a towel in the infusion and place on lower womb for strong cramps.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FAF3E0]">
      {/* Hero Section */}
      <div className="pt-32 pb-20 bg-gradient-to-b from-[#E8B9B9]/20 to-[#FAF3E0]">
        <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="flex items-center justify-center gap-3 mb-4">
              <Sparkles className="w-8 h-8 text-[#D4A017]" />
              <h1 className="text-6xl font-serif text-[#5E0807]">
                {lang === 'pt' ? 'O Ritual' : 'The Ritual'}
              </h1>
              <Sparkles className="w-8 h-8 text-[#D4A017]" />
            </div>
            <p className="text-xl text-[#8C5E5E] max-w-3xl mx-auto leading-relaxed">
              {lang === 'pt'
                ? 'Nossos chás nasceram para ser companheiros mágicos dos seus rituais. Nada sintético, nada agressivo — só a sabedoria ancestral das plantas.'
                : 'Our teas were born to be magical companions of your rituals. Nothing synthetic, nothing aggressive — just the ancestral wisdom of plants.'}
            </p>
          </motion.div>

          {/* Benefits Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 rounded-sm p-6 text-center hover:border-[#D4A017] transition-all"
              >
                <div className="text-4xl mb-3">{benefit.icon}</div>
                <h3 className="font-serif text-[#5E0807] text-lg mb-2">
                  {lang === 'pt' ? benefit.title_pt : benefit.title_en}
                </h3>
                <p className="text-[#8C5E5E] text-sm">
                  {lang === 'pt' ? benefit.desc_pt : benefit.desc_en}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Ritual Steps */}
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-6 md:px-12 lg:px-24">
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-4xl font-serif text-[#5E0807] text-center mb-16"
          >
            {lang === 'pt' ? 'Guia de Preparo Místico' : 'Mystical Preparation Guide'}
          </motion.h2>

          <div className="space-y-4">
            {ritualSteps.map((step, index) => {
              const Icon = step.icon;
              const isExpanded = expandedStep === index;
              const details = lang === 'pt' ? step.details_pt : step.details_en;
              const title = lang === 'pt' ? step.title_pt : step.title_en;
              const desc = lang === 'pt' ? step.desc_pt : step.desc_en;

              return (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border border-[#D4A017]/30 rounded-sm overflow-hidden hover:border-[#D4A017] transition-all"
                >
                  <button
                    onClick={() => setExpandedStep(isExpanded ? -1 : index)}
                    className="w-full p-6 bg-white/50 backdrop-blur-sm hover:bg-white/70 transition-all flex items-center justify-between"
                  >
                    <div className="flex items-center gap-4 text-left">
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: step.color + '20' }}
                      >
                        <Icon className="w-6 h-6" style={{ color: step.color }} />
                      </div>
                      <div>
                        <div className="flex items-center gap-3">
                          <h3 className="text-xl font-serif text-[#5E0807]">{title}</h3>
                          <span className="text-sm text-[#8C5E5E] bg-[#FAF3E0] px-3 py-1 rounded-full">
                            {step.time}
                          </span>
                        </div>
                        <p className="text-[#8C5E5E] text-sm mt-1">{desc}</p>
                      </div>
                    </div>
                    <ChevronDown
                      className={`w-6 h-6 text-[#D4A017] transition-transform ${
                        isExpanded ? 'rotate-180' : ''
                      }`}
                    />
                  </button>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="border-t border-[#D4A017]/30 bg-gradient-to-b from-white/30 to-white/10 p-6"
                      >
                        <ul className="space-y-3">
                          {details.map((detail, i) => (
                            <motion.li
                              key={i}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: i * 0.05 }}
                              className="flex items-center gap-3 text-[#5E0807]/80"
                            >
                              <div className="w-1.5 h-1.5 rounded-full bg-[#D4A017]" />
                              {detail}
                            </motion.li>
                          ))}
                        </ul>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Ritual Methods Section */}
      <div className="py-20 bg-white/30">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <h2 className="text-4xl font-serif text-[#5E0807] text-center mb-16">
            {lang === 'pt' ? 'Métodos de Preparo' : 'Preparation Methods'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {ritualMethods.map((method, index) => {
              const Icon = method.icon;
              return (
                <motion.div
                  key={index}
                  whileHover={{ y: -10 }}
                  className="bg-white/60 p-8 rounded-sm border border-[#D4A017]/20 text-center"
                >
                  <div className="w-16 h-16 bg-[#D4A017]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Icon className="w-8 h-8 text-[#D4A017]" />
                  </div>
                  <h3 className="text-2xl font-serif text-[#5E0807] mb-4">
                    {lang === 'pt' ? method.title_pt : method.title_en}
                  </h3>
                  <p className="text-[#8C5E5E] leading-relaxed">
                    {lang === 'pt' ? method.desc_pt : method.desc_en}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Contraindications Section */}
      <div className="py-20 bg-[#5E0807]/5">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 bg-[#8A1C2B]/10 text-[#8A1C2B] px-4 py-2 rounded-full mb-6">
            <AlertTriangle size={18} />
            <span className="font-medium">{lang === 'pt' ? 'Atenção e Cuidado' : 'Attention and Care'}</span>
          </div>
          <h2 className="text-3xl font-serif text-[#5E0807] mb-6">
            {lang === 'pt' ? 'Contraindicações' : 'Contraindications'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
            <div className="bg-white/40 p-6 rounded-sm border border-[#8A1C2B]/10">
              <h4 className="font-bold text-[#8A1C2B] mb-3">{lang === 'pt' ? 'Geral' : 'General'}</h4>
              <p className="text-[#5E0807]/70 text-sm">
                {lang === 'pt' 
                  ? 'Nossos blends não são indicados para gestantes sem orientação médica. Sempre consulte um profissional de saúde.'
                  : 'Our blends are not indicated for pregnant women without medical guidance. Always consult a healthcare professional.'}
              </p>
            </div>
            <div className="bg-white/40 p-6 rounded-sm border border-[#8A1C2B]/10">
              <h4 className="font-bold text-[#8A1C2B] mb-3">{lang === 'pt' ? 'Banho de Assento' : 'Sitz Bath'}</h4>
              <p className="text-[#5E0807]/70 text-sm">
                {lang === 'pt'
                  ? 'Evite em caso de: infecções ativas (candidíase, vaginose, ITU), pós-parto recente (< 3 meses), feridas, alergias ou DIU de cobre.'
                  : 'Avoid in case of: active infections (candidiasis, vaginosis, UTI), recent postpartum (< 3 months), wounds, allergies or copper IUD.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ritual;
