import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Calendar, User } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const BlogPost = () => {
  const { slug } = useParams();
  const { i18n } = useTranslation();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const lang = i18n.language;

  useEffect(() => {
    fetchPost();
  }, [slug]);

  const fetchPost = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/blog/${slug}`);
      setPost(response.data);
    } catch (error) {
      console.error('Error fetching blog post:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#5E0807]/70">Carregando...</div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-[#5E0807]/70 mb-4">Post não encontrado</div>
        <Link to="/blog" className="text-[#D4A017] hover:underline">
          Voltar para o blog
        </Link>
      </div>
    );
  }

  const title = lang === 'pt' ? post.title_pt : post.title_en;
  const content = lang === 'pt' ? post.content_pt : post.content_en;

  return (
    <div data-testid="blog-post-page" className="min-h-screen py-12 px-6 md:px-12">
      <article className="max-w-4xl mx-auto">
        {/* Back Button */}
        <Link
          to="/blog"
          data-testid="back-to-blog-btn"
          className="inline-flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] mb-8 transition-colors"
        >
          <ArrowLeft size={20} />
          Voltar ao Oráculo
        </Link>

        {/* Featured Image */}
        <div className="aspect-video rounded-sm overflow-hidden border border-[#D4A017]/30 mb-8">
          <img
            src={post.image_url}
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Post Header */}
        <header className="mb-8">
          <h1 data-testid="post-title" className="text-4xl md:text-5xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            {title}
          </h1>
          
          <div className="flex items-center gap-4 text-[#5E0807]/60">
            <span className="flex items-center gap-2">
              <User size={16} />
              {post.author}
            </span>
            <span className="flex items-center gap-2">
              <Calendar size={16} />
              {new Date(post.created_at).toLocaleDateString('pt-BR')}
            </span>
          </div>
        </header>

        {/* Post Content */}
        <div data-testid="post-content" className="prose prose-lg max-w-none">
          <div className="text-[#5E0807]/80 leading-relaxed whitespace-pre-wrap">
            {content}
          </div>
        </div>

        {/* Divider */}
        <div className="my-12 border-t border-[#D4A017]/30" />

        {/* CTA to Products */}
        <div className="text-center bg-[#F5E6D3] border border-[#D4A017]/30 p-8 rounded-sm">
          <h3 className="text-2xl font-medium text-[#5E0807] mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
            Explore nossa coleção de chás místicos
          </h3>
          <Link
            to="/collection"
            data-testid="cta-to-collection-btn"
            className="inline-flex items-center gap-2 bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-medium hover:bg-[#C59010] transition-all duration-300"
          >
            Ver Coleção
            <ArrowLeft size={18} className="rotate-180" />
          </Link>
        </div>
      </article>
    </div>
  );
};

export default BlogPost;
