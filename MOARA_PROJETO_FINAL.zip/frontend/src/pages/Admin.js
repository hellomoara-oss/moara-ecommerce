import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Edit2, Trash2, Eye, EyeOff, ArrowLeft } from 'lucide-react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Admin = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [formData, setFormData] = useState({
    title_pt: '',
    title_en: '',
    slug: '',
    content_pt: '',
    content_en: '',
    excerpt_pt: '',
    excerpt_en: '',
    image_url: '',
    author: '',
    published: false
  });

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/blog`);
      setPosts(response.data);
    } catch (error) {
      console.error('Error fetching posts:', error);
      toast.error('Erro ao carregar posts');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (editingPost) {
        await axios.put(`${BACKEND_URL}/api/blog/${editingPost.id}`, formData);
        toast.success('Post atualizado com sucesso!');
      } else {
        await axios.post(`${BACKEND_URL}/api/blog`, formData);
        toast.success('Post criado com sucesso!');
      }
      
      resetForm();
      fetchPosts();
    } catch (error) {
      console.error('Error saving post:', error);
      toast.error('Erro ao salvar post');
    }
  };

  const handleEdit = (post) => {
    setEditingPost(post);
    setFormData({
      title_pt: post.title_pt,
      title_en: post.title_en,
      slug: post.slug,
      content_pt: post.content_pt,
      content_en: post.content_en,
      excerpt_pt: post.excerpt_pt,
      excerpt_en: post.excerpt_en,
      image_url: post.image_url,
      author: post.author,
      published: post.published
    });
    setShowForm(true);
  };

  const handleDelete = async (postId) => {
    if (!window.confirm('Tem certeza que deseja deletar este post?')) return;
    
    try {
      await axios.delete(`${BACKEND_URL}/api/blog/${postId}`);
      toast.success('Post deletado com sucesso!');
      fetchPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
      toast.error('Erro ao deletar post');
    }
  };

  const resetForm = () => {
    setFormData({
      title_pt: '',
      title_en: '',
      slug: '',
      content_pt: '',
      content_en: '',
      excerpt_pt: '',
      excerpt_en: '',
      image_url: '',
      author: '',
      published: false
    });
    setEditingPost(null);
    setShowForm(false);
  };

  return (
    <div data-testid="admin-page" className="min-h-screen py-12 px-6 md:px-12 bg-[#F5E6D3]">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link
              to="/blog"
              data-testid="back-to-blog-btn"
              className="inline-flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] mb-4 transition-colors"
            >
              <ArrowLeft size={20} />
              Voltar ao Blog
            </Link>
            <h1 data-testid="admin-title" className="text-4xl md:text-5xl font-medium text-[#5E0807]" style={{ fontFamily: 'Playfair Display, serif' }}>
              Administração do Blog
            </h1>
          </div>
          
          {!showForm && (
            <button
              data-testid="new-post-btn"
              onClick={() => setShowForm(true)}
              className="inline-flex items-center gap-2 bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-medium hover:bg-[#C59010] transition-all duration-300"
            >
              <Plus size={20} />
              Novo Post
            </button>
          )}
        </div>

        {/* Form */}
        {showForm && (
          <div data-testid="post-form" className="bg-white border border-[#D4A017]/30 p-8 rounded-sm mb-8">
            <h2 className="text-2xl font-medium text-[#5E0807] mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
              {editingPost ? 'Editar Post' : 'Novo Post'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Título (PT)</label>
                  <input
                    name="title_pt"
                    data-testid="title-pt-input"
                    value={formData.title_pt}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded"
                  />
                </div>
                
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Título (EN)</label>
                  <input
                    name="title_en"
                    data-testid="title-en-input"
                    value={formData.title_en}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#5E0807] font-medium mb-2">Slug (URL)</label>
                <input
                  name="slug"
                  data-testid="slug-input"
                  value={formData.slug}
                  onChange={handleChange}
                  required
                  placeholder="ex: ritual-da-lua-cheia"
                  className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Resumo (PT)</label>
                  <textarea
                    name="excerpt_pt"
                    data-testid="excerpt-pt-input"
                    value={formData.excerpt_pt}
                    onChange={handleChange}
                    required
                    rows={3}
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded resize-none"
                  />
                </div>
                
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Resumo (EN)</label>
                  <textarea
                    name="excerpt_en"
                    data-testid="excerpt-en-input"
                    value={formData.excerpt_en}
                    onChange={handleChange}
                    required
                    rows={3}
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded resize-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Conteúdo (PT)</label>
                  <textarea
                    name="content_pt"
                    data-testid="content-pt-input"
                    value={formData.content_pt}
                    onChange={handleChange}
                    required
                    rows={10}
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded resize-none"
                  />
                </div>
                
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Conteúdo (EN)</label>
                  <textarea
                    name="content_en"
                    data-testid="content-en-input"
                    value={formData.content_en}
                    onChange={handleChange}
                    required
                    rows={10}
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded resize-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">URL da Imagem</label>
                  <input
                    name="image_url"
                    data-testid="image-url-input"
                    value={formData.image_url}
                    onChange={handleChange}
                    required
                    placeholder="https://..."
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded"
                  />
                </div>
                
                <div>
                  <label className="block text-[#5E0807] font-medium mb-2">Autor</label>
                  <input
                    name="author"
                    data-testid="author-input"
                    value={formData.author}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-[#D4A017]/30 focus:border-[#D4A017] outline-none rounded"
                  />
                </div>
              </div>

              <div>
                <label className="flex items-center gap-2 text-[#5E0807] font-medium">
                  <input
                    type="checkbox"
                    name="published"
                    data-testid="published-checkbox"
                    checked={formData.published}
                    onChange={handleChange}
                    className="w-5 h-5"
                  />
                  Publicar post
                </label>
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  data-testid="save-post-btn"
                  className="bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-medium hover:bg-[#C59010] transition-all duration-300"
                >
                  {editingPost ? 'Atualizar' : 'Criar'} Post
                </button>
                
                <button
                  type="button"
                  data-testid="cancel-btn"
                  onClick={resetForm}
                  className="border-2 border-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-medium hover:bg-[#D4A017]/10 transition-all duration-300"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Posts List */}
        {loading ? (
          <div className="text-center text-[#5E0807]/70 py-20">Carregando posts...</div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => (
              <div
                key={post.id}
                data-testid={`post-item-${post.slug}`}
                className="bg-white border border-[#D4A017]/30 p-6 rounded-sm flex items-center justify-between"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-medium text-[#5E0807]" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {post.title_pt}
                    </h3>
                    {post.published ? (
                      <span className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-medium">
                        <Eye size={12} />
                        Publicado
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs font-medium">
                        <EyeOff size={12} />
                        Rascunho
                      </span>
                    )}
                  </div>
                  <p className="text-[#5E0807]/70 text-sm">{post.excerpt_pt}</p>
                  <p className="text-[#5E0807]/50 text-xs mt-2">
                    Por {post.author} • {new Date(post.created_at).toLocaleDateString('pt-BR')}
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    data-testid={`edit-btn-${post.slug}`}
                    onClick={() => handleEdit(post)}
                    className="p-2 text-[#D4A017] hover:bg-[#D4A017]/10 rounded transition-colors"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button
                    data-testid={`delete-btn-${post.slug}`}
                    onClick={() => handleDelete(post.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}

            {posts.length === 0 && (
              <div className="text-center text-[#5E0807]/70 py-20">
                Nenhum post criado ainda. Clique em "Novo Post" para começar.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;
