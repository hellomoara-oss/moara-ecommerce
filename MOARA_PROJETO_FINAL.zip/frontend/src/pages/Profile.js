import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { User, Award, Package, LogOut, Star } from 'lucide-react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Profile = () => {
  const { t } = useTranslation();
  const { user, logout, getAuthHeaders, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [subscriptions, setSubscriptions] = useState([]);
  const [loyaltyTiers, setLoyaltyTiers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    fetchData();
  }, [user]);

  const fetchData = async () => {
    try {
      const [subsResponse, tiersResponse] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/subscriptions/my`, { headers: getAuthHeaders() }),
        axios.get(`${BACKEND_URL}/api/loyalty/tiers`)
      ]);
      setSubscriptions(subsResponse.data);
      setLoyaltyTiers(tiersResponse.data.tiers);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    toast.success('Logout realizado com sucesso!');
    navigate('/');
  };

  const handleRedeemPoints = async () => {
    const points = prompt('Quantos pontos deseja resgatar? (100 pontos = R$10)');
    if (!points || isNaN(points)) return;

    try {
      const response = await axios.post(
        `${BACKEND_URL}/api/loyalty/redeem`,
        parseInt(points),
        { headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' } }
      );
      toast.success(`Cupom gerado: ${response.data.coupon_code} (-R$${response.data.discount_value.toFixed(2)})`);
      refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao resgatar pontos');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#5E0807]/70">Carregando...</div>
      </div>
    );
  }

  const currentTier = loyaltyTiers.find(t => t.name === user?.loyalty_tier);
  const nextTier = loyaltyTiers.find(t => t.min_points > (user?.loyalty_points || 0));

  return (
    <div data-testid="profile-page" className="min-h-screen py-12 px-6 md:px-12">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl md:text-5xl font-medium text-[#5E0807]" style={{ fontFamily: 'Playfair Display, serif' }}>
            Meu Perfil
          </h1>
          <button
            onClick={handleLogout}
            data-testid="logout-btn"
            className="inline-flex items-center gap-2 text-[#5E0807] hover:text-[#D4A017] transition-colors"
          >
            <LogOut size={20} />
            Sair
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* User Info */}
          <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 p-6 rounded-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-16 h-16 bg-[#D4A017] rounded-full flex items-center justify-center">
                <User size={32} className="text-[#5E0807]" />
              </div>
              <div>
                <h2 className="text-xl font-medium text-[#5E0807]" style={{ fontFamily: 'Playfair Display, serif' }}>
                  {user?.name}
                </h2>
                <p className="text-[#5E0807]/70 text-sm">{user?.email}</p>
              </div>
            </div>
            <div className="text-[#5E0807]/60 text-sm">
              Membro desde {new Date(user?.created_at).toLocaleDateString('pt-BR')}
            </div>
          </div>

          {/* Loyalty Points */}
          <div className="bg-gradient-to-br from-[#D4A017]/20 to-[#E8B9B9]/20 border border-[#D4A017]/30 p-6 rounded-sm">
            <div className="flex items-center gap-2 mb-4">
              <Award className="text-[#D4A017]" size={24} />
              <h3 className="text-lg font-medium text-[#5E0807]">Pontos de Fidelidade</h3>
            </div>
            <div className="text-4xl font-bold text-[#D4A017] mb-2">{user?.loyalty_points}</div>
            <div className="text-sm text-[#5E0807]/70 mb-4">
              Nível: <span className="font-medium capitalize">{currentTier?.name_pt || user?.loyalty_tier}</span>
            </div>
            {nextTier && (
              <div className="text-xs text-[#5E0807]/60 mb-4">
                Faltam {nextTier.min_points - user?.loyalty_points} pontos para {nextTier.name_pt}
              </div>
            )}
            <button
              onClick={handleRedeemPoints}
              data-testid="redeem-points-btn"
              className="w-full bg-[#D4A017] text-[#5E0807] py-2 rounded-full text-sm font-medium hover:bg-[#C59010] transition-all"
            >
              Resgatar Pontos
            </button>
          </div>

          {/* Quick Actions */}
          <div className="bg-white/50 backdrop-blur-sm border border-[#D4A017]/30 p-6 rounded-sm">
            <h3 className="text-lg font-medium text-[#5E0807] mb-4">Ações Rápidas</h3>
            <div className="space-y-3">
              <Link
                to="/subscriptions"
                data-testid="subscriptions-link"
                className="block w-full bg-[#E8B9B9] text-[#5E0807] py-2 px-4 rounded-full text-center font-medium hover:bg-[#D4A017]/20 transition-all"
              >
                Ver Assinaturas
              </Link>
              <Link
                to="/collection"
                className="block w-full border border-[#D4A017] text-[#5E0807] py-2 px-4 rounded-full text-center font-medium hover:bg-[#D4A017]/10 transition-all"
              >
                Explorar Produtos
              </Link>
            </div>
          </div>
        </div>

        {/* Loyalty Tiers */}
        <div className="mt-8">
          <h2 className="text-2xl font-medium text-[#5E0807] mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            Níveis de Fidelidade
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {loyaltyTiers.map((tier, index) => (
              <div
                key={tier.name}
                data-testid={`tier-${tier.name}`}
                className={`border-2 p-6 rounded-sm ${
                  tier.name === user?.loyalty_tier
                    ? 'border-[#D4A017] bg-[#D4A017]/10'
                    : 'border-[#D4A017]/30 bg-white/50'
                }`}
              >
                <div className="flex items-center gap-2 mb-3">
                  <Star className="text-[#D4A017]" size={20} />
                  <h3 className="text-xl font-medium text-[#5E0807]" style={{ fontFamily: 'Playfair Display, serif' }}>
                    {tier.name_pt}
                  </h3>
                </div>
                <p className="text-sm text-[#5E0807]/70 mb-4">
                  A partir de {tier.min_points} pontos
                </p>
                <ul className="space-y-2">
                  {tier.benefits_pt.map((benefit, i) => (
                    <li key={i} className="text-sm text-[#5E0807]/80 flex items-start gap-2">
                      <span className="text-[#D4A017]">•</span>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* My Subscriptions */}
        <div className="mt-8">
          <h2 className="text-2xl font-medium text-[#5E0807] mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
            Minhas Assinaturas
          </h2>
          {subscriptions.length === 0 ? (
            <div className="bg-white/50 border border-[#D4A017]/30 p-8 rounded-sm text-center">
              <Package className="mx-auto text-[#D4A017] mb-4" size={48} />
              <p className="text-[#5E0807]/70 mb-4">Você ainda não tem assinaturas ativas</p>
              <Link
                to="/subscriptions"
                className="inline-block bg-[#D4A017] text-[#5E0807] px-6 py-3 rounded-full font-medium hover:bg-[#C59010] transition-all"
              >
                Explorar Planos
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {subscriptions.map((sub) => (
                <div
                  key={sub.id}
                  data-testid={`subscription-${sub.id}`}
                  className="bg-white/50 border border-[#D4A017]/30 p-6 rounded-sm flex items-center justify-between"
                >
                  <div>
                    <h3 className="text-lg font-medium text-[#5E0807] mb-2">
                      Plano {sub.plan === 'monthly' ? 'Mensal' : sub.plan === 'quarterly' ? 'Trimestral' : 'Anual'}
                    </h3>
                    <p className="text-sm text-[#5E0807]/70">
                      R$ {sub.price.toFixed(2)} • Próxima entrega: {new Date(sub.next_delivery).toLocaleDateString('pt-BR')}
                    </p>
                    <p className="text-xs text-[#5E0807]/60 mt-1">
                      Status: <span className={sub.status === 'active' ? 'text-green-600' : 'text-red-600'}>{sub.status === 'active' ? 'Ativa' : 'Cancelada'}</span>
                    </p>
                  </div>
                  {sub.status === 'active' && (
                    <button
                      onClick={async () => {
                        if (window.confirm('Deseja cancelar esta assinatura?')) {
                          try {
                            await axios.put(
                              `${BACKEND_URL}/api/subscriptions/${sub.id}/cancel`,
                              {},
                              { headers: getAuthHeaders() }
                            );
                            toast.success('Assinatura cancelada');
                            fetchData();
                          } catch (error) {
                            toast.error('Erro ao cancelar');
                          }
                        }
                      }}
                      className="text-sm text-red-600 hover:text-red-700 font-medium"
                    >
                      Cancelar
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
