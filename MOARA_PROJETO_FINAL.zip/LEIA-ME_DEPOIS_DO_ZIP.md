# 🚀 Como Colocar o Moara no Ar em 5 Minutos

Olá! Este é o pacote final do seu site **Moara**. Siga estes passos simples para torná-lo permanente:

---

## 💎 Parte 1: O Site (Frontend)
1. Acesse [Vercel.com](https://vercel.com) e crie uma conta (pode usar seu email ou GitHub).
2. Clique em **"Add New"** > **"Project"**.
3. Em vez de conectar ao GitHub, clique em **"upload your project"** e arraste a pasta `frontend` deste ZIP para lá.
4. Clique em **Deploy**.
5. **Pronto!** A Vercel vai te dar um link (ex: `moara.vercel.app`).

---

## 🧠 Parte 2: O Cérebro (Backend)
O site precisa de um lugar para salvar os pedidos e avaliações.
1. Acesse [Railway.app](https://railway.app) e crie uma conta.
2. Clique em **"New Project"** > **"Deploy from GitHub repo"** (ou arraste a pasta `backend`).
3. Nas configurações, adicione as **Variáveis de Ambiente** que estão no arquivo `.env.example`.
4. Use a sua string do **MongoDB Atlas** que configuramos:
   `mongodb+srv://hellomoara:RPZA0OWTIC7lqB2C@cluster0.dt6jrun.mongodb.net/?retryWrites=true&w=majority`

---

## 🎨 Como Editar Depois?
- **Textos:** Abra a pasta `frontend/src/i18n.js`. Lá você pode mudar qualquer frase do site.
- **Produtos:** No arquivo `backend/server_mock.py`, você pode alterar preços, nomes e imagens.
- **Imagens:** Substitua os links de imagens na lista de produtos.

---

## ✅ O que está incluído neste pacote:
- **Site Completo:** Carrinho, Checkout, Favoritos, Oráculo, Ritual.
- **Produtos Reais:** Selvagem, Pôr do Sol, Chá da Deusa, etc.
- **Design Atualizado:** Sem as luas, com brilhos misticos e cursor especial.
- **Bilíngue:** Tudo pronto em Português e Inglês.

**Sucesso com a Moara! Autocuidado é um ato revolucionário. 🌸**
