from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime, timezone, timedelta
import uuid
import json

app = FastAPI(title="Moara API - Mock")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class Product(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name_pt: str
    name_en: str
    slug: str
    category: str
    price: float
    description_pt: str
    description_en: str
    benefits_pt: List[str]
    benefits_en: List[str]
    ingredients_pt: List[str]
    ingredients_en: List[str]
    image_url: str
    label_color: str
    mercado_livre_url: str
    featured: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Newsletter(BaseModel):
    email: EmailStr

class CartItem(BaseModel):
    product_id: str
    quantity: int
    price: float

class Order(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    items: List[CartItem]
    total: float
    customer_email: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# In-memory storage
products_db = []
newsletter_db = []
orders_db = []

# Initial products updated with real data from PDFs
initial_products = [
    {
        'name_pt': 'Pôr do Sol',
        'name_en': 'Sunset',
        'slug': 'por-do-sol',
        'category': 'solar',
        'price': 35.00,
        'description_pt': 'Blend harmonioso de Camomila e Calêndula. Um companheiro mágico para seus rituais, criado a partir de estudos em fitoenergética e herbalismo.',
        'description_en': 'Harmonious blend of Chamomile and Calendula. A magical companion for your rituals, created from studies in phytoenergetics and herbalism.',
        'benefits_pt': ['Acalma ansiedade', 'Alivia cólicas', 'Cuida da sua pele', 'Promove relaxamento profundo'],
        'benefits_en': ['Calms anxiety', 'Relieves cramps', 'Cares for your skin', 'Promotes deep relaxation'],
        'ingredients_pt': ['Camomila', 'Calêndula'],
        'ingredients_en': ['Chamomile', 'Calendula'],
        'image_url': 'https://images.unsplash.com/photo-1635397399593-6dd454f2a67f?w=800&q=80',
        'label_color': '#8A1C2B',
        'mercado_livre_url': 'https://www.mercadolivre.com.br',
        'featured': True
    },
    {
        'name_pt': 'Chá da Deusa',
        'name_en': 'Goddess Tea',
        'slug': 'cha-da-deusa',
        'category': 'divine',
        'price': 42.00,
        'description_pt': 'Cuidado uterino resgatando práticas ancestrais. Ideal para a Fase Menstrual e Lua Nova, auxiliando nos sintomas da TPM.',
        'description_en': 'Uterine care rescuing ancestral practices. Ideal for the Menstrual Phase and New Moon, helping with PMS symptoms.',
        'benefits_pt': ['Auxilia nos sintomas da TPM', 'Alivia cólicas', 'Aquece o ventre', 'Conexão com a ancestralidade'],
        'benefits_en': ['Helps with PMS symptoms', 'Relieves cramps', 'Warms the womb', 'Connection with ancestry'],
        'ingredients_pt': ['Camomila', 'Calêndula', 'Artemísia', 'Melissa'],
        'ingredients_en': ['Chamomile', 'Calendula', 'Artemisia', 'Lemon Balm'],
        'image_url': 'https://images.unsplash.com/photo-1715180850209-266308def5bd?w=800&q=80',
        'label_color': '#E8B9B9',
        'mercado_livre_url': 'https://www.mercadolivre.com.br',
        'featured': True
    },
    {
        'name_pt': 'Óleo Selvagem',
        'name_en': 'Wild Oil',
        'slug': 'oleo-selvagem',
        'category': 'hair_oil',
        'price': 48.00,
        'description_pt': 'Óleo capilar herbal para cuidar do volume & crescimento. Criado para cabelos crespos e enrolados que vivem e expandem.',
        'description_en': 'Herbal hair oil to care for volume & growth. Created for curly and coily hair that lives and expands.',
        'benefits_pt': ['Cuida do volume', 'Estimula crescimento', 'Raiz firme e expansão', 'Brilho natural'],
        'benefits_en': ['Cares for volume', 'Stimulates growth', 'Firm root and expansion', 'Natural shine'],
        'ingredients_pt': ['Hibisco', 'Alecrim', 'Amla', 'Lavanda', 'Vitamina E'],
        'ingredients_en': ['Hibiscus', 'Rosemary', 'Amla', 'Lavender', 'Vitamin E'],
        'image_url': 'https://images.unsplash.com/photo-1596178065887-ba9ecf66efc5?w=800&q=80',
        'label_color': '#D4A017',
        'mercado_livre_url': 'https://www.mercadolivre.com.br',
        'featured': True
    },
    {
        'name_pt': 'Artemísia Pura',
        'name_en': 'Pure Artemisia',
        'slug': 'artemisia-pura',
        'category': 'divine',
        'price': 38.00,
        'description_pt': 'Erva sagrada que estimula o fluxo menstrual e limpa energias densas do ventre. Excelente para banhos de assento.',
        'description_en': 'Sacred herb that stimulates menstrual flow and cleanses dense energies from the womb. Excellent for sitz baths.',
        'benefits_pt': ['Estimula fluxo menstrual', 'Regula ciclos irregulares', 'Limpa energias densas', 'Abre consciência corporal'],
        'benefits_en': ['Stimulates menstrual flow', 'Regulates irregular cycles', 'Cleanses dense energies', 'Opens body awareness'],
        'ingredients_pt': ['Artemísia'],
        'ingredients_en': ['Artemisia'],
        'image_url': 'https://images.unsplash.com/photo-1597318972632-c1c98c5c1d5f?w=800&q=80',
        'label_color': '#4A7C59',
        'mercado_livre_url': 'https://www.mercadolivre.com.br',
        'featured': False
    },
    {
        'name_pt': 'Melissa & Paz',
        'name_en': 'Lemon Balm & Peace',
        'slug': 'melissa-paz',
        'category': 'solar',
        'price': 32.00,
        'description_pt': 'Reduz ansiedade e irritação. Uma energia de descanso profundo que acalma pensamentos acelerados.',
        'description_en': 'Reduces anxiety and irritation. An energy of deep rest that calms racing thoughts.',
        'benefits_pt': ['Reduz ansiedade', 'Melhora qualidade do sono', 'Acalma pensamentos', 'Descanso profundo'],
        'benefits_en': ['Reduces anxiety', 'Improves sleep quality', 'Calms thoughts', 'Deep rest'],
        'ingredients_pt': ['Melissa'],
        'ingredients_en': ['Lemon Balm'],
        'image_url': 'https://images.unsplash.com/photo-1636388556982-17edafdec669?w=800&q=80',
        'label_color': '#0F1C3A',
        'mercado_livre_url': 'https://www.mercadolivre.com.br',
        'featured': False
    }
]

# Initialize products
for product in initial_products:
    p = Product(**product)
    products_db.append(p.model_dump())

# Routes
@app.get("/")
async def root():
    return {"message": "Moara API - Mock Version", "status": "online"}

@app.get("/api/products")
async def get_products(category: Optional[str] = None, featured: Optional[bool] = None):
    """Get all products with optional filtering"""
    result = products_db
    
    if category:
        result = [p for p in result if p['category'] == category]
    
    if featured is not None:
        result = [p for p in result if p['featured'] == featured]
    
    return result

@app.get("/api/products/{slug}")
async def get_product(slug: str):
    """Get a specific product by slug"""
    for product in products_db:
        if product['slug'] == slug:
            return product
    raise HTTPException(status_code=404, detail="Product not found")

@app.post("/api/products")
async def create_product(product: Product):
    """Create a new product"""
    product_dict = product.model_dump()
    products_db.append(product_dict)
    return product_dict

@app.post("/api/newsletter")
async def subscribe_newsletter(newsletter: Newsletter):
    """Subscribe to newsletter"""
    if newsletter.email in [n['email'] for n in newsletter_db]:
        raise HTTPException(status_code=400, detail="Email already subscribed")
    
    newsletter_db.append({
        'email': newsletter.email,
        'subscribed_at': datetime.now(timezone.utc).isoformat()
    })
    
    return {"message": "Subscribed successfully", "email": newsletter.email}

@app.post("/api/orders")
async def create_order(order: Order):
    """Create a new order"""
    order_dict = order.model_dump()
    orders_db.append(order_dict)
    return order_dict

@app.get("/api/orders")
async def get_orders():
    """Get all orders"""
    return orders_db

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "products": len(products_db),
        "newsletters": len(newsletter_db),
        "orders": len(orders_db)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
