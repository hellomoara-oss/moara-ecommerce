from fastapi import FastAPI, APIRouter, HTTPException, Body, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import jwt
from passlib.context import CryptContext

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Security
SECRET_KEY = os.environ.get('SECRET_KEY', 'moara-secret-key-change-in-production')
ALGORITHM = "HS256"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Helper functions
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(days=7)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if user is None:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Models
class Product(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name_pt: str
    name_en: str
    slug: str
    category: str
    price: float
    description_pt: str
    description_en: str
    benefits_pt: List[str]
    benefits_en: List[str]
    ingredients_pt: List[str]
    ingredients_en: List[str]
    image_url: str
    label_color: str
    mercado_livre_url: str
    featured: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProductCreate(BaseModel):
    name_pt: str
    name_en: str
    slug: str
    category: str
    price: float
    description_pt: str
    description_en: str
    benefits_pt: List[str]
    benefits_en: List[str]
    ingredients_pt: List[str]
    ingredients_en: List[str]
    image_url: str
    label_color: str
    mercado_livre_url: str
    featured: bool = False

class Newsletter(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: str
    language: str = "pt"
    subscribed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class NewsletterCreate(BaseModel):
    email: str
    language: str = "pt"

class BlogPost(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title_pt: str
    title_en: str
    slug: str
    content_pt: str
    content_en: str
    excerpt_pt: str
    excerpt_en: str
    image_url: str
    author: str
    published: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class BlogPostCreate(BaseModel):
    title_pt: str
    title_en: str
    slug: str
    content_pt: str
    content_en: str
    excerpt_pt: str
    excerpt_en: str
    image_url: str
    author: str
    published: bool = False

class BlogPostUpdate(BaseModel):
    title_pt: Optional[str] = None
    title_en: Optional[str] = None
    slug: Optional[str] = None
    content_pt: Optional[str] = None
    content_en: Optional[str] = None
    excerpt_pt: Optional[str] = None
    excerpt_en: Optional[str] = None
    image_url: Optional[str] = None
    author: Optional[str] = None
    published: Optional[bool] = None

class QuizResult(BaseModel):
    recommended_product: str
    coupon_code: str

# User Models
class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: str
    password_hash: str
    loyalty_points: int = 0
    loyalty_tier: str = "bronze"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserProfile(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    email: str
    name: str
    loyalty_points: int
    loyalty_tier: str
    created_at: datetime

# Review Models
class Review(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    product_slug: str
    user_id: str
    user_name: str
    rating: int
    comment: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ReviewCreate(BaseModel):
    product_slug: str
    rating: int
    comment: str

# Subscription Models
class Subscription(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    plan: str
    products: List[str]
    status: str = "active"
    price: float
    next_delivery: datetime
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SubscriptionCreate(BaseModel):
    plan: str
    products: List[str]

# Products endpoints
@api_router.get("/products", response_model=List[Product])
async def get_products(category: Optional[str] = None, featured: Optional[bool] = None):
    query = {}
    if category:
        query["category"] = category
    if featured is not None:
        query["featured"] = featured
    
    products = await db.products.find(query, {"_id": 0}).to_list(1000)
    for product in products:
        if isinstance(product.get('created_at'), str):
            product['created_at'] = datetime.fromisoformat(product['created_at'])
    return products

@api_router.get("/products/{slug}", response_model=Product)
async def get_product(slug: str):
    product = await db.products.find_one({"slug": slug}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    if isinstance(product.get('created_at'), str):
        product['created_at'] = datetime.fromisoformat(product['created_at'])
    return product

@api_router.post("/products", response_model=Product)
async def create_product(product: ProductCreate):
    product_obj = Product(**product.model_dump())
    doc = product_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.products.insert_one(doc)
    return product_obj

# Newsletter endpoints
@api_router.post("/newsletter")
async def subscribe_newsletter(newsletter: NewsletterCreate):
    existing = await db.newsletter.find_one({"email": newsletter.email}, {"_id": 0})
    if existing:
        return {"message": "Email already subscribed", "status": "existing"}
    
    newsletter_obj = Newsletter(**newsletter.model_dump())
    doc = newsletter_obj.model_dump()
    doc['subscribed_at'] = doc['subscribed_at'].isoformat()
    await db.newsletter.insert_one(doc)
    return {"message": "Successfully subscribed", "status": "new"}

# Blog endpoints
@api_router.get("/blog", response_model=List[BlogPost])
async def get_blog_posts(published: Optional[bool] = None):
    query = {}
    if published is not None:
        query["published"] = published
    
    posts = await db.blog_posts.find(query, {"_id": 0}).sort("created_at", -1).to_list(1000)
    for post in posts:
        if isinstance(post.get('created_at'), str):
            post['created_at'] = datetime.fromisoformat(post['created_at'])
        if isinstance(post.get('updated_at'), str):
            post['updated_at'] = datetime.fromisoformat(post['updated_at'])
    return posts

@api_router.get("/blog/{slug}", response_model=BlogPost)
async def get_blog_post(slug: str):
    post = await db.blog_posts.find_one({"slug": slug}, {"_id": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Blog post not found")
    if isinstance(post.get('created_at'), str):
        post['created_at'] = datetime.fromisoformat(post['created_at'])
    if isinstance(post.get('updated_at'), str):
        post['updated_at'] = datetime.fromisoformat(post['updated_at'])
    return post

@api_router.post("/blog", response_model=BlogPost)
async def create_blog_post(post: BlogPostCreate):
    post_obj = BlogPost(**post.model_dump())
    doc = post_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    await db.blog_posts.insert_one(doc)
    return post_obj

@api_router.put("/blog/{post_id}", response_model=BlogPost)
async def update_blog_post(post_id: str, post_update: BlogPostUpdate):
    existing_post = await db.blog_posts.find_one({"id": post_id}, {"_id": 0})
    if not existing_post:
        raise HTTPException(status_code=404, detail="Blog post not found")
    
    update_data = {k: v for k, v in post_update.model_dump().items() if v is not None}
    update_data['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.blog_posts.update_one({"id": post_id}, {"$set": update_data})
    
    updated_post = await db.blog_posts.find_one({"id": post_id}, {"_id": 0})
    if isinstance(updated_post.get('created_at'), str):
        updated_post['created_at'] = datetime.fromisoformat(updated_post['created_at'])
    if isinstance(updated_post.get('updated_at'), str):
        updated_post['updated_at'] = datetime.fromisoformat(updated_post['updated_at'])
    return updated_post

@api_router.delete("/blog/{post_id}")
async def delete_blog_post(post_id: str):
    result = await db.blog_posts.delete_one({"id": post_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Blog post not found")
    return {"message": "Blog post deleted successfully"}

# Quiz endpoint
@api_router.post("/quiz", response_model=QuizResult)
async def quiz_recommendation(answers: dict = Body(...)):
    challenge = answers.get("challenge", "")
    
    recommendations = {
        "anxiety": {"product": "por-do-sol", "coupon": "CALMA10"},
        "sleep": {"product": "lua-de-mel", "coupon": "SONO10"},
        "pms": {"product": "cha-da-deusa", "coupon": "DEUSA10"},
        "default": {"product": "por-do-sol", "coupon": "BEM10"}
    }
    
    rec = recommendations.get(challenge, recommendations["default"])
    return QuizResult(
        recommended_product=rec["product"],
        coupon_code=rec["coupon"]
    )

# Auth endpoints
@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    existing_user = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user = User(
        email=user_data.email,
        name=user_data.name,
        password_hash=hash_password(user_data.password)
    )
    
    doc = user.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.users.insert_one(doc)
    
    access_token = create_access_token(data={"sub": user.id})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": UserProfile(
            id=user.id,
            email=user.email,
            name=user.name,
            loyalty_points=user.loyalty_points,
            loyalty_tier=user.loyalty_tier,
            created_at=user.created_at
        )
    }

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    user = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user or not verify_password(credentials.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    access_token = create_access_token(data={"sub": user["id"]})
    
    if isinstance(user.get('created_at'), str):
        user['created_at'] = datetime.fromisoformat(user['created_at'])
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": UserProfile(
            id=user["id"],
            email=user["email"],
            name=user["name"],
            loyalty_points=user["loyalty_points"],
            loyalty_tier=user["loyalty_tier"],
            created_at=user["created_at"]
        )
    }

@api_router.get("/auth/me", response_model=UserProfile)
async def get_current_user_profile(current_user: dict = Depends(get_current_user)):
    if isinstance(current_user.get('created_at'), str):
        current_user['created_at'] = datetime.fromisoformat(current_user['created_at'])
    
    return UserProfile(
        id=current_user["id"],
        email=current_user["email"],
        name=current_user["name"],
        loyalty_points=current_user["loyalty_points"],
        loyalty_tier=current_user["loyalty_tier"],
        created_at=current_user["created_at"]
    )

# Reviews endpoints
@api_router.get("/reviews/{product_slug}")
async def get_product_reviews(product_slug: str):
    reviews = await db.reviews.find({"product_slug": product_slug}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    for review in reviews:
        if isinstance(review.get('created_at'), str):
            review['created_at'] = datetime.fromisoformat(review['created_at'])
    return reviews

@api_router.post("/reviews", response_model=Review)
async def create_review(review_data: ReviewCreate, current_user: dict = Depends(get_current_user)):
    review = Review(
        product_slug=review_data.product_slug,
        user_id=current_user["id"],
        user_name=current_user["name"],
        rating=review_data.rating,
        comment=review_data.comment
    )
    
    doc = review.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.reviews.insert_one(doc)
    
    # Add loyalty points for review (10 points)
    await db.users.update_one(
        {"id": current_user["id"]},
        {"$inc": {"loyalty_points": 10}}
    )
    
    return review

@api_router.get("/reviews/{product_slug}/stats")
async def get_review_stats(product_slug: str):
    reviews = await db.reviews.find({"product_slug": product_slug}, {"_id": 0}).to_list(1000)
    
    if not reviews:
        return {
            "average_rating": 0,
            "total_reviews": 0,
            "rating_distribution": {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
        }
    
    total_reviews = len(reviews)
    average_rating = sum(r["rating"] for r in reviews) / total_reviews
    
    rating_distribution = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for review in reviews:
        rating_distribution[review["rating"]] += 1
    
    return {
        "average_rating": round(average_rating, 1),
        "total_reviews": total_reviews,
        "rating_distribution": rating_distribution
    }

# Subscriptions endpoints
@api_router.get("/subscriptions/plans")
async def get_subscription_plans():
    return {
        "plans": [
            {
                "id": "monthly",
                "name": "Mensal",
                "name_en": "Monthly",
                "duration": "1 mês",
                "duration_en": "1 month",
                "discount": 0,
                "description_pt": "Receba seus chás todo mês",
                "description_en": "Receive your teas every month"
            },
            {
                "id": "quarterly",
                "name": "Trimestral",
                "name_en": "Quarterly",
                "duration": "3 meses",
                "duration_en": "3 months",
                "discount": 10,
                "description_pt": "10% de desconto + brinde especial",
                "description_en": "10% discount + special gift"
            },
            {
                "id": "yearly",
                "name": "Anual",
                "name_en": "Yearly",
                "duration": "12 meses",
                "duration_en": "12 months",
                "discount": 20,
                "description_pt": "20% de desconto + brindes exclusivos",
                "description_en": "20% discount + exclusive gifts"
            }
        ]
    }

@api_router.post("/subscriptions", response_model=Subscription)
async def create_subscription(sub_data: SubscriptionCreate, current_user: dict = Depends(get_current_user)):
    # Calculate price based on plan
    products = await db.products.find({"slug": {"$in": sub_data.products}}, {"_id": 0}).to_list(100)
    base_price = sum(p["price"] for p in products)
    
    discount = 0
    if sub_data.plan == "quarterly":
        discount = 0.10
    elif sub_data.plan == "yearly":
        discount = 0.20
    
    final_price = base_price * (1 - discount)
    
    # Calculate next delivery date
    if sub_data.plan == "monthly":
        next_delivery = datetime.now(timezone.utc) + timedelta(days=30)
    elif sub_data.plan == "quarterly":
        next_delivery = datetime.now(timezone.utc) + timedelta(days=90)
    else:
        next_delivery = datetime.now(timezone.utc) + timedelta(days=365)
    
    subscription = Subscription(
        user_id=current_user["id"],
        plan=sub_data.plan,
        products=sub_data.products,
        price=final_price,
        next_delivery=next_delivery
    )
    
    doc = subscription.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['next_delivery'] = doc['next_delivery'].isoformat()
    await db.subscriptions.insert_one(doc)
    
    # Add loyalty points for subscription (50 points)
    await db.users.update_one(
        {"id": current_user["id"]},
        {"$inc": {"loyalty_points": 50}}
    )
    
    return subscription

@api_router.get("/subscriptions/my")
async def get_my_subscriptions(current_user: dict = Depends(get_current_user)):
    subscriptions = await db.subscriptions.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("created_at", -1).to_list(1000)
    
    for sub in subscriptions:
        if isinstance(sub.get('created_at'), str):
            sub['created_at'] = datetime.fromisoformat(sub['created_at'])
        if isinstance(sub.get('next_delivery'), str):
            sub['next_delivery'] = datetime.fromisoformat(sub['next_delivery'])
    
    return subscriptions

@api_router.put("/subscriptions/{subscription_id}/cancel")
async def cancel_subscription(subscription_id: str, current_user: dict = Depends(get_current_user)):
    subscription = await db.subscriptions.find_one(
        {"id": subscription_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    
    if not subscription:
        raise HTTPException(status_code=404, detail="Subscription not found")
    
    await db.subscriptions.update_one(
        {"id": subscription_id},
        {"$set": {"status": "cancelled"}}
    )
    
    return {"message": "Subscription cancelled successfully"}

# Loyalty points endpoints
@api_router.get("/loyalty/tiers")
async def get_loyalty_tiers():
    return {
        "tiers": [
            {
                "name": "bronze",
                "name_pt": "Bronze",
                "min_points": 0,
                "benefits_pt": ["5% de desconto", "Frete grátis acima de R$100"],
                "benefits_en": ["5% discount", "Free shipping over R$100"]
            },
            {
                "name": "silver",
                "name_pt": "Prata",
                "min_points": 500,
                "benefits_pt": ["10% de desconto", "Frete grátis acima de R$80", "Acesso antecipado a lançamentos"],
                "benefits_en": ["10% discount", "Free shipping over R$80", "Early access to launches"]
            },
            {
                "name": "gold",
                "name_pt": "Ouro",
                "min_points": 1000,
                "benefits_pt": ["15% de desconto", "Frete grátis sempre", "Produtos exclusivos", "Consulta com especialista"],
                "benefits_en": ["15% discount", "Always free shipping", "Exclusive products", "Expert consultation"]
            }
        ]
    }

@api_router.post("/loyalty/redeem")
async def redeem_points(points: int = Body(...), current_user: dict = Depends(get_current_user)):
    if current_user["loyalty_points"] < points:
        raise HTTPException(status_code=400, detail="Insufficient points")
    
    # 100 points = R$10 discount
    discount_value = (points / 100) * 10
    
    # Generate coupon code
    coupon_code = f"PONTOS{points}"
    
    # Deduct points
    await db.users.update_one(
        {"id": current_user["id"]},
        {"$inc": {"loyalty_points": -points}}
    )
    
    return {
        "coupon_code": coupon_code,
        "discount_value": discount_value,
        "remaining_points": current_user["loyalty_points"] - points
    }

@api_router.get("/")
async def root():
    return {"message": "Moara API - Portal Linear Apothecary"}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
